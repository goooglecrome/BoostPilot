# BoostPilot

**A Windows gaming and PC optimisation control centre.**

BoostPilot is a Windows 10/11 x64 desktop application built with .NET 8 WPF. The current rebuild includes a first-run setup wizard with a dedicated progress/completion screen, a reversible master Optimizer, Windows Game Mode preferences, a conditional reversible High Performance power-plan option for desktop maximum-performance profiles, CPU/RAM diagnostics, network ping testing, a temp-file review/cleanup tool, an animated collapsing sidebar, and a Windows installer build workflow.

## Build

See [docs/DEVELOPMENT.md](docs/DEVELOPMENT.md) for local build instructions and the current feature boundaries. GitHub Actions builds a self-contained Windows application and packages it with Inno Setup. Push a `v*` tag to publish an installer release.

## Safety principles

- Review before applying system changes.
- Deactivate the Optimizer and restore the saved settings before uninstalling the app.
- Back up and restore every Windows value the master Optimizer modifies.
- Do not disable Windows Defender, Windows Update, the firewall, or essential services.
- Avoid generic voltage, memory timing, and fan-control sliders. These require hardware-specific validation.
- Report task results truthfully; do not invent FPS or ping improvements.

## Status

Development build. Not yet validated on a physical Windows 10/11 PC or signed with a code-signing certificate. Do not treat it as a stable production release yet.
