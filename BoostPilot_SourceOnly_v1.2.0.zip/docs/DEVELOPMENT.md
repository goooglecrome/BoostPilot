# BoostPilot development guide

## Requirements

- Windows 10 or Windows 11 x64
- .NET 8 SDK
- Inno Setup 6 (only when building the installer)

## Build locally

```powershell
dotnet restore .\src\BoostPilot.App\BoostPilot.App.csproj
dotnet publish .\src\BoostPilot.App\BoostPilot.App.csproj -c Release -r win-x64 --self-contained true -o .\artifacts\publish
```

To create the installer, install Inno Setup 6 and run:

```powershell
iscc /DBuildVersion=1.2.0 .\installer\BoostPilot.iss
```

The installer is generated at `artifacts\BoostPilot-Setup.exe`.

## GitHub releases and update checks

The desktop app checks `https://api.github.com/repos/goooglecrome/BoostPilot/releases/latest` when it opens. It only offers a link to a published release; it does not silently replace files or execute downloaded installers. Tag a release as `v1.2.1` after changing `VERSION` and the project version. The GitHub Actions workflow builds an installer and attaches it to the release.

## Current behaviour and limitations

- The master Optimizer backs up the current `HKCU\Software\Microsoft\GameBar` values for `AutoGameModeEnabled` and `AllowAutoGameMode`, enables both, verifies them, and restores the prior values when disabled.
- For a desktop profile that selects **Maximum gaming performance**, the Optimizer also checks whether the built-in Windows High Performance power plan is available. If available, it saves the currently active plan, activates High Performance, and verifies the change. Laptop, balanced, quiet, unavailable-plan, and already-active cases are skipped. Deactivation restores the saved power plan. High Performance can use more electricity and create more heat.
- Hardware discovery reads CPU and GPU names through WMI, the processor's reported maximum clock, reported RAM module speed, and total/available physical memory. CPU load is read through a Windows performance counter. The module speed value is SMBIOS/WMI-reported information and may not represent the currently trained memory data rate. GPU engine utilisation is not yet exposed because counter availability varies by driver; Task Manager remains the reference for that live metric.
- Ping tests measure five ICMP round trips to `1.1.1.1`; this does not represent every game's server route.
- The DNS flush button runs `ipconfig /flushdns`; DNS cache clearing is not presented as a ping reduction.
- The cleanup page scans the current user's temporary folder for files older than 14 days and asks for confirmation before deletion. Files in use are skipped.
- Per-game GPU preferences open Windows Graphics settings rather than forcing undocumented vendor driver settings.
- RAM speed, XMP/EXPO, CPU/GPU clocks and fan curves are not changed. They require motherboard/firmware/vendor-specific support.

## Safety

The application requests administrator approval using its Windows application manifest. It does not disable Defender, Windows Update, firewall protections, or essential services. Optimisations are reviewed before application, and the values modified by the master Optimizer are saved for restoration. Deactivate the Optimizer and restore its saved settings before uninstalling the application.

## Testing

The GitHub Actions workflow compiles and packages the app on `windows-latest`. The source still needs validation on physical Windows 10/11 machines and a range of GPU/motherboard vendors before being advertised as a stable release. The installer is not code-signed yet.
