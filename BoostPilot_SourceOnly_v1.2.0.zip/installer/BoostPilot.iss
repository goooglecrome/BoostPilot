#ifndef BuildVersion
  #define BuildVersion "1.2.0"
#endif
#define AppName "BoostPilot"
#define AppExe "BoostPilot.exe"

[Setup]
AppId={{B80C6A32-E875-4C5D-9AE1-43D9D8C82026}
AppName={#AppName}
AppVersion={#BuildVersion}
AppPublisher=BoostPilot
DefaultDirName={autopf}\BoostPilot
DefaultGroupName=BoostPilot
OutputDir=..\artifacts
OutputBaseFilename=BoostPilot-Setup
SetupIconFile=..\src\BoostPilot.App\BoostPilot.ico
UninstallDisplayIcon={app}\{#AppExe}
ArchitecturesInstallIn64BitMode=x64
PrivilegesRequired=admin
DisableProgramGroupPage=yes
WizardStyle=modern
Compression=lzma2
SolidCompression=yes
CloseApplications=force
RestartApplications=no

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Additional shortcuts:"; Flags: unchecked

[Files]
Source: "..\artifacts\publish\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\BoostPilot"; Filename: "{app}\{#AppExe}"; WorkingDir: "{app}"
Name: "{autodesktop}\BoostPilot"; Filename: "{app}\{#AppExe}"; WorkingDir: "{app}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#AppExe}"; Description: "Launch BoostPilot"; Flags: nowait postinstall skipifsilent
