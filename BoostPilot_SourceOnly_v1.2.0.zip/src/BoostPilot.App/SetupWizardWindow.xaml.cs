using BoostPilot.Services;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace BoostPilot;

public partial class SetupWizardWindow : Window
{
    private readonly UserSettings _settings = SettingsStore.Load();
    private int _step;
    private ComboBox _device = new(), _goal = new(), _network = new(), _automation = new();
    private TextBox _games = new();
    private bool _applying;

    public SetupWizardWindow()
    {
        InitializeComponent();
        Closing += (_, e) => { if (_applying) e.Cancel = true; };
        RenderStep();
    }

    private void RenderStep()
    {
        WizardProgress.Value = _step + 1; StepCount.Text = $"STEP {_step + 1} OF 6";
        BackButton.IsEnabled = _step > 0 && !_applying; NextButton.IsEnabled = !_applying;
        var s = new StackPanel();
        switch (_step)
        {
            case 0:
                s.Children.Add(Heading("Welcome to BoostPilot", "Let's learn about your PC so we can build a sensible gaming profile."));
                s.Children.Add(Info("Detected system", $"Windows {Environment.OSVersion.Version} · {Environment.ProcessorCount} logical processors"));
                s.Children.Add(Label("What kind of computer do you use?")); _device = Combo("Desktop PC", "Gaming laptop", "Other laptop"); _device.SelectedItem = _settings.DeviceType switch { "Gaming laptop" => "Gaming laptop", "Other laptop" => "Other laptop", _ => "Desktop PC" }; s.Children.Add(_device);
                s.Children.Add(Info("Hardware controls", "BoostPilot will detect visible CPU, GPU and RAM information. Fan curves and memory timings depend on your motherboard and vendor software.")); break;
            case 1:
                s.Children.Add(Heading("What's your main goal?", "We'll use this to recommend the right Windows profile."));
                _goal = Combo("Maximum gaming performance", "Balanced performance", "Smooth gaming and streaming", "Quiet and cool operation"); _goal.SelectedItem = _settings.Goal; s.Children.Add(Label("Choose your priority")); s.Children.Add(_goal);
                s.Children.Add(Info("A realistic promise", "The same tweak does not improve every PC. BoostPilot will explain each change and show whether it was applied successfully.")); break;
            case 2:
                s.Children.Add(Heading("Which games do you play?", "List the main games you want BoostPilot to help you configure."));
                _games = new TextBox { Text = _settings.Games, Height = 42, FontSize = 14, Background = new SolidColorBrush(Color.FromRgb(24, 40, 61)), Foreground = Brushes.White, BorderBrush = new SolidColorBrush(Color.FromRgb(49, 70, 94)), Padding = new Thickness(12, 9, 12, 9), Margin = new Thickness(0, 8, 0, 14) }; s.Children.Add(Label("Games (optional)")); s.Children.Add(_games);
                s.Children.Add(Info("Examples", "Fortnite, Minecraft, Roblox, Valorant, Apex Legends or the games you play most.")); break;
            case 3:
                s.Children.Add(Heading("Let's check your network", "A ping test measures the delay to a test host. Game-server latency can be different."));
                _network = Combo("Ethernet", "Wi-Fi", "Mobile hotspot", "Not sure"); _network.SelectedItem = _settings.NetworkType; s.Children.Add(Label("How is your PC connected?")); s.Children.Add(_network);
                s.Children.Add(Info("Ping preferences", "BoostPilot can measure average latency and packet loss and provide practical connection checks. It cannot control ISP routing or server distance.")); break;
            case 4:
                s.Children.Add(Heading("How automatic should it be?", "You stay in control of every system change."));
                _automation = Combo("Ask before applying changes", "Automatically apply safe changes after review", "Manual controls only"); _automation.SelectedItem = _settings.Automation; s.Children.Add(Label("Choose how BoostPilot behaves")); s.Children.Add(_automation);
                s.Children.Add(Info("Safety", "BoostPilot does not disable Windows Defender, security updates or essential services. It backs up settings it changes and offers a restore option.")); break;
            case 5:
                s.Children.Add(Heading("Your profile is ready", "Review your choices. Nothing is changed until you approve the plan."));
                s.Children.Add(Info("Device", _settings.DeviceType)); s.Children.Add(Info("Goal", _settings.Goal)); s.Children.Add(Info("Games", string.IsNullOrWhiteSpace(_settings.Games) ? "Not specified" : _settings.Games)); s.Children.Add(Info("Network", _settings.NetworkType)); s.Children.Add(Info("Automation", _settings.Automation));
                s.Children.Add(Info("Changes in this build", "Back up existing Windows Game Mode values, enable the Windows Game Mode preferences, then verify them. For a desktop using Maximum gaming performance, BoostPilot can also switch Windows to its built-in High Performance power plan and save the previous plan for restoration. This can increase heat and power use. Hardware clocks, CPU/GPU voltage, RAM speed/timings, fan curves and network routing are not changed."));
                s.Children.Add(Info("What happens next", "After you approve, BoostPilot opens a dedicated progress screen. It reports the real task progress and ends with a result for every task."));
                NextButton.Content = _settings.Automation == "Manual controls only" ? "Save profile" : "Apply profile"; break;
        }
        if (_step != 5) NextButton.Content = "Next";
        StepHost.Content = s;
    }

    private void Back_Click(object sender, RoutedEventArgs e) { if (_step <= 0 || _applying) return; CaptureStep(); _step--; RenderStep(); }
    private void Next_Click(object sender, RoutedEventArgs e)
    {
        if (_applying) return;
        if (_step < 5) { CaptureStep(); _step++; RenderStep(); return; }
        _ = ApplyAndFinishAsync();
    }
    private void CaptureStep()
    {
        if (_step == 0) _settings.DeviceType = _device.SelectedItem?.ToString() ?? "Desktop PC";
        if (_step == 1) _settings.Goal = _goal.SelectedItem?.ToString() ?? "Balanced performance";
        if (_step == 2) _settings.Games = _games.Text.Trim();
        if (_step == 3) _settings.NetworkType = _network.SelectedItem?.ToString() ?? "Not sure";
        if (_step == 4) _settings.Automation = _automation.SelectedItem?.ToString() ?? "Ask before applying changes";
    }

    private async Task ApplyAndFinishAsync()
    {
        CaptureStep();
        _settings.WizardCompleted = true;
        if (_settings.Automation == "Manual controls only")
        {
            _settings.OptimizerEnabled = false;
            SettingsStore.Save(_settings);
            DialogResult = true;
            return;
        }
        if (_settings.Automation == "Ask before applying changes" && MessageBox.Show("Apply the reviewed profile? BoostPilot will back up the existing Windows settings first. A desktop profile set to Maximum gaming performance may also activate the Windows High Performance power plan, which can increase heat and power use.", "Review and approve", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
        {
            _settings.OptimizerEnabled = false;
            SettingsStore.Save(_settings);
            DialogResult = true;
            return;
        }

        _applying = true;
        BackButton.IsEnabled = false;
        NextButton.IsEnabled = false;
        NextButton.Content = "Applying…";
        StepCount.Text = "APPLYING YOUR PROFILE";
        var progressBar = new ProgressBar { Height = 12, Minimum = 0, Maximum = 100, Background = new SolidColorBrush(Color.FromRgb(36, 56, 80)), Foreground = new SolidColorBrush(Color.FromRgb(80, 221, 176)), Margin = new Thickness(0, 18, 0, 10) };
        var percentText = new TextBlock { Text = "0%", FontSize = 34, FontWeight = FontWeights.Bold, Foreground = new SolidColorBrush(Color.FromRgb(80, 221, 176)), HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 14, 0, 8) };
        var statusText = new TextBlock { Text = "Preparing optimisation…", FontSize = 12, Foreground = new SolidColorBrush(Color.FromRgb(160, 181, 203)), HorizontalAlignment = HorizontalAlignment.Center, TextWrapping = TextWrapping.Wrap };
        var progressView = new StackPanel { VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(10, 25, 10, 25) };
        progressView.Children.Add(Heading("Boosting your PC", "Applying the approved Windows settings and checking that they took effect."));
        progressView.Children.Add(percentText); progressView.Children.Add(progressBar); progressView.Children.Add(statusText);
        StepHost.Content = progressView;

        try
        {
            var progress = new Progress<(int Percent, string Task)>(v =>
            {
                progressBar.Value = v.Percent;
                percentText.Text = $"{v.Percent}%";
                statusText.Text = v.Task;
            });
            var result = await new OptimizerService().SetEnabledAsync(true, progress, profile: _settings);
            bool failed = result.Tasks.Any(t => t.Status == "Failed");
            _settings.WizardCompleted = true;
            _settings.OptimizerEnabled = result.Enabled;
            SettingsStore.Save(_settings);
            _applying = false; // Allow the Done button to close the wizard after work finishes.
            StepCount.Text = failed ? "FINISHED WITH ISSUES" : "SETUP COMPLETE";
            WizardProgress.Value = 6;
            StepHost.Content = BuildCompletionView(failed, result.Tasks);
            BackButton.Visibility = Visibility.Collapsed;
            NextButton.Content = "Done";
            NextButton.IsEnabled = true;
            NextButton.Click -= Next_Click;
            NextButton.Click += Finish_Click;
        }
        catch (Exception ex)
        {
            _settings.WizardCompleted = true;
            _settings.OptimizerEnabled = false;
            SettingsStore.Save(_settings);
            _applying = false; // Allow the user to close the results screen after a failure.
            StepCount.Text = "SETUP COULD NOT BE COMPLETED";
            WizardProgress.Value = 6;
            StepHost.Content = BuildCompletionView(true, new[] { new OptimizationTaskResult("Optimisation", "Failed", ex.Message) });
            BackButton.Visibility = Visibility.Collapsed;
            NextButton.Content = "Done";
            NextButton.IsEnabled = true;
            NextButton.Click -= Next_Click;
            NextButton.Click += Finish_Click;
        }
    }

    private static UIElement BuildCompletionView(bool failed, IReadOnlyList<OptimizationTaskResult> results)
    {
        var panel = new StackPanel { VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(4, 12, 4, 12) };
        panel.Children.Add(Heading(failed ? "Finished with issues" : "Optimisation complete!", failed ? "Review the results below. Failed tasks are listed clearly, and settings that could not be restored are not reported as restored." : "Your approved profile has been applied and the settings check has finished."));
        var status = new TextBlock { Text = failed ? "CHECK THE TASK RESULTS" : "DONE", FontSize = 28, FontWeight = FontWeights.Bold, Foreground = new SolidColorBrush(failed ? Color.FromRgb(240, 180, 95) : Color.FromRgb(80, 221, 176)), HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 12, 0, 18) };
        panel.Children.Add(status);
        foreach (var item in results)
        {
            panel.Children.Add(Info(item.Status.ToUpperInvariant() + " · " + item.Name, item.Detail));
        }
        return new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Content = panel };
    }

    private void Finish_Click(object sender, RoutedEventArgs e) { DialogResult = true; }
    private void Cancel_Click(object sender, RoutedEventArgs e) { if (_applying) return; DialogResult = false; }

    private static UIElement Heading(string title, string subtitle) { var p = new StackPanel { Margin = new Thickness(0, 0, 0, 20) }; p.Children.Add(new TextBlock { Text = title, FontSize = 25, FontWeight = FontWeights.Bold, Foreground = Brushes.White, Margin = new Thickness(0, 0, 0, 7) }); p.Children.Add(new TextBlock { Text = subtitle, FontSize = 12, Foreground = new SolidColorBrush(Color.FromRgb(158, 180, 202)), TextWrapping = TextWrapping.Wrap }); return p; }
    private static TextBlock Label(string text) => new() { Text = text, Foreground = Brushes.White, FontSize = 12, FontWeight = FontWeights.SemiBold, Margin = new Thickness(0, 10, 0, 5) };
    private static Border Info(string title, string text) { var s = new StackPanel(); s.Children.Add(new TextBlock { Text = title.ToUpperInvariant(), Foreground = new SolidColorBrush(Color.FromRgb(80, 221, 176)), FontSize = 9, FontWeight = FontWeights.SemiBold }); s.Children.Add(new TextBlock { Text = text, Foreground = new SolidColorBrush(Color.FromRgb(181, 199, 219)), FontSize = 12, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 4, 0, 0) }); return new Border { Background = new SolidColorBrush(Color.FromRgb(24, 40, 61)), CornerRadius = new CornerRadius(9), Padding = new Thickness(13), Margin = new Thickness(0, 8, 0, 0), Child = s }; }
    private static ComboBox Combo(params string[] items) { var c = new ComboBox { ItemsSource = items, Height = 38, FontSize = 13, Padding = new Thickness(8), Background = new SolidColorBrush(Color.FromRgb(24, 40, 61)), Foreground = Brushes.White, BorderBrush = new SolidColorBrush(Color.FromRgb(49, 70, 94)), Margin = new Thickness(0, 4, 0, 8) }; c.SelectedIndex = 0; return c; }
}
