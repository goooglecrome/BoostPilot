using BoostPilot.Services;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace BoostPilot;

public partial class OptimizationProgressWindow : Window
{
    private readonly bool _enabling;
    public OptimizationProgressWindow(bool enabling) { InitializeComponent(); _enabling = enabling; TitleText.Text = enabling ? "OPTIMISING YOUR PC" : "RESTORING YOUR SETTINGS"; }
    public void Report(int percent, string task) { Progress.Value = percent; PercentText.Text = $"{percent}%"; StatusText.Text = task; }
    public void AddResult(OptimizationTaskResult result)
    {
        var row = new Grid { Margin = new Thickness(0, 4, 0, 4) }; row.ColumnDefinitions.Add(new ColumnDefinition()); row.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        var copy = new StackPanel(); copy.Children.Add(new TextBlock { Text = result.Name, Foreground = Brushes.White, FontWeight = FontWeights.SemiBold, FontSize = 12 }); copy.Children.Add(new TextBlock { Text = result.Detail, Foreground = new SolidColorBrush(Color.FromRgb(151, 174, 198)), FontSize = 10, TextWrapping = TextWrapping.Wrap });
        var status = new TextBlock { Text = result.Status.ToUpperInvariant(), Foreground = new SolidColorBrush(result.Status == "Complete" ? Color.FromRgb(80, 221, 176) : result.Status == "Failed" ? Color.FromRgb(255, 135, 125) : Color.FromRgb(221, 184, 97)), FontSize = 10, FontWeight = FontWeights.Bold, Margin = new Thickness(10, 0, 0, 0), VerticalAlignment = VerticalAlignment.Top };
        row.Children.Add(copy); Grid.SetColumn(status, 1); row.Children.Add(status); ResultsList.Items.Add(row);
    }
    public void Complete(bool failed) { Report(100, failed ? "Finished with one or more errors" : "All selected tasks finished"); TitleText.Text = failed ? "FINISHED WITH ISSUES" : (_enabling ? "OPTIMISATION COMPLETE" : "RESTORE COMPLETE"); DoneButton.Content = "Done"; DoneButton.IsEnabled = true; }
    private void Done_Click(object sender, RoutedEventArgs e) => Close();
}
