using BoostPilot.Services;
using Microsoft.Win32;
using System.Diagnostics;
using System.Net.NetworkInformation;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;

namespace BoostPilot;

public partial class MainWindow : Window
{
    private readonly SystemMonitor _monitor = new();
    private readonly OptimizerService _optimizer = new();
    private readonly UserSettings _settings = SettingsStore.Load();
    private readonly DispatcherTimer _timer = new() { Interval = TimeSpan.FromSeconds(3) };
    private bool _expanded = true;
    private bool _wizardShown;
    private string _page = "Dashboard";
    private SystemSnapshot? _snapshot;
    private readonly Dictionary<string, Button> _navButtons = new();

    public MainWindow()
    {
        InitializeComponent();
        AddNav("Dashboard", "⌂"); AddNav("FPS Booster", "⚡"); AddNav("Ping Booster", "◉"); AddNav("Hardware", "▦"); AddNav("PC Cleanup", "▤");
        _timer.Tick += async (_, _) => await RefreshSnapshotAsync();
        _timer.Start();
        UpdateOptimizerIndicator();
        SetPage("Dashboard");
    }

    private void AddNav(string name, string glyph)
    {
        var button = new Button { Background = Brushes.Transparent, BorderThickness = new Thickness(0), HorizontalContentAlignment = HorizontalAlignment.Stretch, Padding = new Thickness(12, 11, 8, 11), Margin = new Thickness(0, 2, 0, 2), ToolTip = name, Tag = name };
        var row = new StackPanel { Orientation = Orientation.Horizontal };
        row.Children.Add(new TextBlock { Text = glyph, FontSize = 18, Width = 28, VerticalAlignment = VerticalAlignment.Center });
        row.Children.Add(new TextBlock { Text = name, FontSize = 12, VerticalAlignment = VerticalAlignment.Center, Name = "NavItemText" });
        button.Content = row; button.Click += (_, _) => SetPage(name);
        _navButtons[name] = button; NavHost.Children.Add(button);
    }

    private async void Window_Loaded(object sender, RoutedEventArgs e)
    {
        await RefreshSnapshotAsync();
        if (!_settings.WizardCompleted && !_wizardShown)
        {
            _wizardShown = true;
            var wizard = new SetupWizardWindow { Owner = this };
            if (wizard.ShowDialog() == true)
            {
                var loaded = SettingsStore.Load();
                CopySettings(loaded, _settings); UpdateOptimizerIndicator(); SetPage("Dashboard");
            }
        }
        _ = CheckForUpdatesAsync();
    }

    private static void CopySettings(UserSettings from, UserSettings to)
    {
        to.WizardCompleted = from.WizardCompleted; to.DeviceType = from.DeviceType; to.Goal = from.Goal; to.Games = from.Games; to.NetworkType = from.NetworkType; to.Automation = from.Automation; to.OptimizerEnabled = from.OptimizerEnabled;
    }

    private void Sidebar_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e) => SetSidebarExpanded(true);
    private void Sidebar_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e) => SetSidebarExpanded(false);
    private void SetSidebarExpanded(bool expand)
    {
        if (_expanded == expand) return; _expanded = expand;
        var animation = new GridLengthAnimation { From = SidebarColumn.Width, To = new GridLength(expand ? 214 : 76), Duration = TimeSpan.FromMilliseconds(190), EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut } };
        SidebarColumn.BeginAnimation(ColumnDefinition.WidthProperty, animation);
        BrandText.Visibility = expand ? Visibility.Visible : Visibility.Collapsed;
        NavLabel.Visibility = expand ? Visibility.Visible : Visibility.Collapsed;
        SidebarStatus.Visibility = expand ? Visibility.Visible : Visibility.Collapsed;
        SettingsNavText.Visibility = expand ? Visibility.Visible : Visibility.Collapsed;
        foreach (var btn in _navButtons.Values)
        {
            if (btn.Content is StackPanel sp && sp.Children.Count > 1) sp.Children[1].Visibility = expand ? Visibility.Visible : Visibility.Collapsed;
            btn.HorizontalContentAlignment = expand ? HorizontalAlignment.Stretch : HorizontalAlignment.Center;
            btn.Padding = expand ? new Thickness(12, 11, 8, 11) : new Thickness(0, 11, 0, 11);
        }
    }

    private void SetPage(string name)
    {
        _page = name; PageTitle.Text = name;
        PageSubtitle.Text = name switch { "Dashboard" => "Your PC performance at a glance", "FPS Booster" => "Gaming settings and frame-rate diagnostics", "Ping Booster" => "Measure connection latency and packet loss", "Hardware" => "Live system information and component details", "PC Cleanup" => "Review temporary files before removing them", _ => "BoostPilot preferences" };
        foreach (var item in _navButtons) item.Value.Background = item.Key == name ? new SolidColorBrush(Color.FromRgb(31, 63, 78)) : Brushes.Transparent;
        PageHost.Content = name switch
        {
            "Dashboard" => BuildDashboard(), "FPS Booster" => BuildFpsPage(), "Ping Booster" => BuildPingPage(), "Hardware" => BuildHardwarePage(), "PC Cleanup" => BuildCleanupPage(), _ => BuildSettingsPage()
        };
    }

    private UIElement BuildDashboard()
    {
        var stack = PageStack();
        var hero = new Border { Background = new LinearGradientBrush(Color.FromRgb(24, 67, 66), Color.FromRgb(20, 37, 57), 0), CornerRadius = new CornerRadius(18), Padding = new Thickness(24), Margin = new Thickness(0, 0, 0, 16) };
        var heroGrid = new Grid(); heroGrid.ColumnDefinitions.Add(new ColumnDefinition()); heroGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        var copy = new StackPanel(); copy.Children.Add(Text("YOUR GAMING PROFILE", 10, Color.FromRgb(139, 221, 199), true)); copy.Children.Add(Text("Make every session count.", 26, Colors.White, true)); copy.Children.Add(Text("BoostPilot applies measured, reversible Windows settings — not mystery tweaks.", 12, Color.FromRgb(192, 214, 216))); copy.Children.Add(new Button { Content = "Open FPS Booster", Width = 148, HorizontalAlignment = HorizontalAlignment.Left, Margin = new Thickness(0, 16, 0, 0), Background = new SolidColorBrush(Color.FromRgb(47, 137, 113)) }); ((Button)copy.Children[^1]).Click += (_, _) => SetPage("FPS Booster");
        heroGrid.Children.Add(copy); var toggle = new StackPanel { VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(26, 0, 4, 0), Width = 170 }; toggle.Children.Add(Text("MASTER OPTIMIZER", 10, Color.FromRgb(194, 214, 216), true)); toggle.Children.Add(Text(_settings.OptimizerEnabled ? "ACTIVE" : "INACTIVE", 24, _settings.OptimizerEnabled ? Color.FromRgb(80, 221, 176) : Color.FromRgb(167, 183, 202), true)); var btn = new Button { Content = _settings.OptimizerEnabled ? "Deactivate optimizer" : "Activate optimizer", Margin = new Thickness(0, 8, 0, 0), Background = new SolidColorBrush(_settings.OptimizerEnabled ? Color.FromRgb(86, 63, 61) : Color.FromRgb(42, 127, 104)) }; btn.Click += async (_, _) => await ToggleOptimizerAsync(); toggle.Children.Add(btn); Grid.SetColumn(toggle, 1); heroGrid.Children.Add(toggle); hero.Child = heroGrid; stack.Children.Add(hero);
        var metrics = new UniformGrid { Columns = 3, Margin = new Thickness(0, 0, 0, 16) };
        metrics.Children.Add(MetricCard("CPU LOAD", _snapshot is null ? "—" : $"{_snapshot.CpuPercent:0}%", "Processor usage", "◉"));
        metrics.Children.Add(MetricCard("MEMORY", _snapshot is null ? "—" : $"{_snapshot.MemoryUsedGb:0.0} / {_snapshot.MemoryTotalGb:0.0} GB", "In use / total RAM", "▦"));
        metrics.Children.Add(MetricCard("NETWORK", NetworkInterface.GetIsNetworkAvailable() ? "Connected" : "Offline", "Connection status", "⌁")); stack.Children.Add(metrics);
        stack.Children.Add(SectionTitle("Quick actions")); var quick = new UniformGrid { Columns = 2 };
        quick.Children.Add(ActionCard("Run setup wizard", "Review your goals and create a profile", () => ShowWizard())); quick.Children.Add(ActionCard("Test ping", "Measure latency to Cloudflare DNS", () => SetPage("Ping Booster"))); stack.Children.Add(quick);
        var note = Card(); note.Child = new StackPanel { Children = { Text("A note about performance", 14, Colors.White, true), Text("BoostPilot cannot guarantee a specific FPS or lower the ping to a game server. It measures your PC and applies supported settings. CPU/GPU clocks, RAM timings and fan curves need compatible hardware tools.", 12, Color.FromRgb(160, 181, 203)) } }; stack.Children.Add(note);
        return stack;
    }

    private UIElement BuildFpsPage()
    {
        var stack = PageStack();
        stack.Children.Add(SectionTitle("Gaming performance"));
        var info = Card(); info.Child = new StackPanel { Children = { Text("Windows Game Mode", 17, Colors.White, true), Text("Game Mode helps Windows prioritise your active game. The master Optimizer can enable this setting and restore the values it found before activation.", 12, Color.FromRgb(160, 181, 203)), MakeAsyncButton(_settings.OptimizerEnabled ? "Optimizer is active" : "Activate gaming profile", async _ => await ToggleOptimizerAsync()) } }; stack.Children.Add(info);
        var gpu = Card(); gpu.Child = new StackPanel { Children = { Text("Per-game GPU preference", 17, Colors.White, true), Text("Choose a High performance GPU for a specific game in Windows Graphics settings. This is safer than forcing a global driver profile.", 12, Color.FromRgb(160, 181, 203)), MakeButton("Open Windows Graphics settings", (_, _) => OpenUri("ms-settings:display-graphics")) } }; stack.Children.Add(gpu);
        var capture = Card(); capture.Child = new StackPanel { Children = { Text("Background recording", 17, Colors.White, true), Text("Recording clips can use system resources. Review Windows Captures settings and disable background recording only if you do not use it.", 12, Color.FromRgb(160, 181, 203)), MakeButton("Open Captures settings", (_, _) => OpenUri("ms-settings:gaming-gamedvr")) } }; stack.Children.Add(capture);
        var warning = Card(); warning.Child = new StackPanel { Children = { Text("FPS measurement", 14, Colors.White, true), Text("BoostPilot does not invent an FPS number. Use the in-game benchmark or a trusted overlay to measure before and after changes. A change is only an improvement when your measured result confirms it.", 12, Color.FromRgb(160, 181, 203)) } }; stack.Children.Add(warning);
        return stack;
    }

    private UIElement BuildPingPage()
    {
        var stack = PageStack(); var card = Card(); var body = new StackPanel(); body.Children.Add(Text("Connection test", 18, Colors.White, true)); body.Children.Add(Text("Send five test packets to 1.1.1.1. This measures your route to Cloudflare DNS, not the latency to every game server.", 12, Color.FromRgb(160, 181, 203))); var result = Text("No test run yet", 22, Color.FromRgb(80, 221, 176), true); result.Margin = new Thickness(0, 16, 0, 12); body.Children.Add(result); var details = Text("Average —   Min —   Max —   Packet loss —", 12, Color.FromRgb(160, 181, 203)); body.Children.Add(details); var test = MakeAsyncButton("Run ping test", async b => { b.IsEnabled = false; result.Text = "Testing connection…"; try { var r = await NetworkService.TestAsync(); result.Text = r.AverageMs is null ? "No reply received" : $"{r.AverageMs:0} ms average"; details.Text = $"Average {r.AverageMs:0} ms   Min {r.MinMs:0} ms   Max {r.MaxMs:0} ms   Loss {r.LossPercent:0}% ({r.Received}/{r.Sent})"; } catch (Exception ex) { result.Text = "Test failed: " + ex.Message; } finally { b.IsEnabled = true; } }); body.Children.Add(test); card.Child = body; stack.Children.Add(card);
        var dns = Card(); dns.Child = new StackPanel { Children = { Text("DNS cache", 17, Colors.White, true), Text("Clearing the local DNS cache can help when a website's address has recently changed. It does not usually reduce game ping.", 12, Color.FromRgb(160, 181, 203)), MakeButton("Flush DNS cache", (_, _) => FlushDns()) } }; stack.Children.Add(dns);
        var advice = Card(); advice.Child = new StackPanel { Children = { Text("Ways to improve connection stability", 14, Colors.White, true), Text("Use Ethernet where practical, pause large downloads while gaming, check for Wi-Fi interference, and choose the closest available game region. Internet routing and server distance are outside this app's control.", 12, Color.FromRgb(160, 181, 203)) } }; stack.Children.Add(advice); return stack;
    }

    private UIElement BuildHardwarePage()
    {
        var stack = PageStack(); stack.Children.Add(SectionTitle("Detected hardware"));
        string cpuClock = _snapshot?.CpuMaxClockMhz is int maxClock ? $"{maxClock} MHz" : "—";
        string ramSpeed = _snapshot?.RamModuleSpeedMhz is int moduleSpeed ? $"{moduleSpeed} MHz" : "—";
        stack.Children.Add(InfoCard("Processor", _snapshot?.CpuName ?? "Detecting…", "CPU load / reported max clock", _snapshot is null ? "—" : $"{_snapshot.CpuPercent:0}% / {cpuClock}"));
        stack.Children.Add(InfoCard("Graphics", _snapshot?.GpuName ?? "Detecting…", "GPU usage", "Open Task Manager for live GPU engine utilisation"));
        stack.Children.Add(InfoCard("Memory", _snapshot is null ? "Detecting…" : $"{_snapshot.MemoryTotalGb:0.0} GB installed", "In use / reported module speed", _snapshot is null ? "—" : $"{_snapshot.MemoryUsedGb:0.0} GB / {ramSpeed}"));
        stack.Children.Add(InfoCard("Windows", _snapshot?.WindowsVersion ?? "Detecting…", "Hardware controls", "RAM XMP, fan curves and voltage are handled by compatible BIOS/vendor utilities."));
        var tools = Card(); tools.Child = new StackPanel { Children = { Text("Hardware tools", 16, Colors.White, true), MakeButton("Open Task Manager", (_, _) => Process.Start(new ProcessStartInfo("taskmgr.exe") { UseShellExecute = true })), MakeButton("Manage startup apps", (_, _) => OpenUri("ms-settings:startupapps")), MakeButton("Open Windows power settings", (_, _) => OpenUri("ms-settings:powersleep")), MakeButton("Open UEFI / Advanced startup options", (_, _) => OpenUefi()) } }; stack.Children.Add(tools); return stack;
    }

    private UIElement BuildCleanupPage()
    {
        var stack = PageStack(); var card = Card(); var body = new StackPanel(); body.Children.Add(Text("Temporary file review", 18, Colors.White, true)); body.Children.Add(Text("BoostPilot can scan your user temporary folder and remove files older than 14 days. Files in use are skipped. This does not remove Downloads, browser data or personal documents.", 12, Color.FromRgb(160, 181, 203))); var count = Text("Run a scan to see what can be removed.", 14, Color.FromRgb(80, 221, 176), true); count.Margin = new Thickness(0, 14, 0, 10); body.Children.Add(count); var scan = MakeAsyncButton("Scan temporary files", async b => { b.IsEnabled = false; var n = await Task.Run(() => CleanupService.Scan()); count.Text = $"{n.Count:N0} files · {n.SizeMb:0.0} MB potentially removable"; b.IsEnabled = true; }); body.Children.Add(scan); body.Children.Add(MakeAsyncButton("Remove files older than 14 days", async _ => { var ask = MessageBox.Show("Remove eligible temporary files older than 14 days? Files in use will be skipped.", "Confirm cleanup", MessageBoxButton.YesNo, MessageBoxImage.Warning); if (ask != MessageBoxResult.Yes) return; var n = await Task.Run(() => CleanupService.Clean()); MessageBox.Show($"Removed {n.Removed} files ({n.SizeMb:0.0} MB). {n.Skipped} files were skipped.", "Cleanup finished", MessageBoxButton.OK, MessageBoxImage.Information); })); card.Child = body; stack.Children.Add(card); return stack;
    }

    private UIElement BuildSettingsPage()
    {
        var stack = PageStack(); var wizard = Card(); wizard.Child = new StackPanel { Children = { Text("Your optimisation profile", 17, Colors.White, true), Text($"Device: {_settings.DeviceType}\nGoal: {_settings.Goal}\nGames: {(_settings.Games.Length == 0 ? "Not specified" : _settings.Games)}\nNetwork: {_settings.NetworkType}\nAutomation: {_settings.Automation}", 12, Color.FromRgb(160, 181, 203)), MakeButton("Edit setup wizard", (_, _) => ShowWizard()) } }; stack.Children.Add(wizard);
        var restore = Card(); restore.Child = new StackPanel { Children = { Text("Restore settings", 17, Colors.White, true), Text("Turn the master Optimizer off to restore the saved Windows Game Mode values. This only restores values BoostPilot backed up.", 12, Color.FromRgb(160, 181, 203)), MakeAsyncButton("Deactivate and restore", async _ => { if (_settings.OptimizerEnabled) await ToggleOptimizerAsync(false); else MessageBox.Show("The optimizer is already inactive."); }) } }; stack.Children.Add(restore);
        var update = Card(); update.Child = new StackPanel { Children = { Text("Updates", 17, Colors.White, true), Text("BoostPilot checks the configured GitHub Releases page for a newer version. Updates are offered for you to review; they are not silently installed.", 12, Color.FromRgb(160, 181, 203)), MakeAsyncButton("Check for updates", async _ => await CheckForUpdatesAsync(true)) } }; stack.Children.Add(update); return stack;
    }

    private async Task ToggleOptimizerAsync(bool? desired = null)
    {
        bool enable = desired ?? !_settings.OptimizerEnabled;
        if (enable && MessageBox.Show("BoostPilot will back up the current Game Mode values and enable Windows Game Mode preferences. If your survey selected a desktop with Maximum gaming performance, it will also try to enable Windows High Performance power mode and back up the previous plan. That can increase heat and power use. No clocks, voltages, RAM timings or fan curves will be changed. Continue?", "Activate Optimizer", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
        if (!enable && MessageBox.Show("Turn off BoostPilot and restore the saved Game Mode settings?", "Deactivate Optimizer", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
        var progressWindow = new OptimizationProgressWindow(enable) { Owner = this }; progressWindow.Show();
        try
        {
            var progress = new Progress<(int Percent, string Task)>(v => progressWindow.Report(v.Percent, v.Task));
            var result = await _optimizer.SetEnabledAsync(enable, progress, profile: _settings);
            foreach (var t in result.Tasks) progressWindow.AddResult(t);
            _settings.OptimizerEnabled = result.Enabled; SettingsStore.Save(_settings); UpdateOptimizerIndicator(); progressWindow.Complete(result.Tasks.Any(t => t.Status == "Failed"));
            SetPage(_page);
        }
        catch (Exception ex) { progressWindow.AddResult(new("Optimiser", "Failed", ex.Message)); progressWindow.Complete(true); }
    }

    private void UpdateOptimizerIndicator()
    {
        StatusDot.Fill = new SolidColorBrush(_settings.OptimizerEnabled ? Color.FromRgb(80, 221, 176) : Color.FromRgb(128, 147, 169)); SidebarStatus.Text = _settings.OptimizerEnabled ? "Active" : "Inactive";
    }

    private async Task RefreshSnapshotAsync()
    {
        try { _snapshot = await _monitor.ReadAsync(); if (_page == "Dashboard" || _page == "Hardware") SetPage(_page); } catch { }
    }

    private async Task CheckForUpdatesAsync(bool showCurrent = false)
    {
        const string repo = "goooglecrome/BoostPilot";
        try
        {
            using var client = new HttpClient(); client.DefaultRequestHeaders.UserAgent.ParseAdd("BoostPilot-UpdateChecker/1.2"); client.Timeout = TimeSpan.FromSeconds(5);
            var json = await client.GetStringAsync($"https://api.github.com/repos/{repo}/releases/latest"); using var doc = System.Text.Json.JsonDocument.Parse(json); var tag = doc.RootElement.GetProperty("tag_name").GetString() ?? "";
            var current = typeof(MainWindow).Assembly.GetName().Version?.ToString(3) ?? "1.2.0";
            if (Version.TryParse(tag.TrimStart('v'), out var latest) && Version.TryParse(current, out var installed) && latest > installed)
            {
                if (MessageBox.Show($"BoostPilot {latest} is available. Open the release page?", "Update available", MessageBoxButton.YesNo, MessageBoxImage.Information) == MessageBoxResult.Yes) OpenUri($"https://github.com/{repo}/releases/latest");
            }
            else if (showCurrent) MessageBox.Show("You're running the latest published BoostPilot version, or no newer release is available.", "Update check", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch { if (showCurrent) MessageBox.Show("Could not check GitHub Releases right now. Check your internet connection and try again.", "Update check", MessageBoxButton.OK, MessageBoxImage.Warning); }
    }

    private void ShowWizard() { var w = new SetupWizardWindow { Owner = this }; if (w.ShowDialog() == true) { CopySettings(SettingsStore.Load(), _settings); SetPage("Dashboard"); } }
    private void WizardButton_Click(object sender, RoutedEventArgs e) => ShowWizard();
    private void SettingsNav_Click(object sender, RoutedEventArgs e) => SetPage("Settings");
    private void FlushDns() { try { var p = Process.Start(new ProcessStartInfo("ipconfig.exe", "/flushdns") { UseShellExecute = false, RedirectStandardOutput = true, CreateNoWindow = true }); var output = p?.StandardOutput.ReadToEnd() ?? ""; p?.WaitForExit(5000); MessageBox.Show(output.Length > 0 ? output : "DNS cache flush command completed.", "DNS cache", MessageBoxButton.OK, MessageBoxImage.Information); } catch (Exception ex) { MessageBox.Show(ex.Message, "DNS cache", MessageBoxButton.OK, MessageBoxImage.Error); } }
    private void OpenUefi() { if (MessageBox.Show("Windows will open Recovery settings. To reach UEFI, choose Advanced startup > Restart now, then select UEFI Firmware Settings. Save your work first. Continue?", "Open UEFI options", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes) return; try { OpenUri("ms-settings:recovery"); } catch (Exception ex) { MessageBox.Show(ex.Message); } }
    private static void OpenUri(string uri) { try { Process.Start(new ProcessStartInfo(uri) { UseShellExecute = true }); } catch (Exception ex) { MessageBox.Show(ex.Message, "Could not open Windows settings"); } }

    private StackPanel PageStack() => new() { Margin = new Thickness(0, 0, 4, 24) };
    private static TextBlock Text(string text, double size = 13, Color? color = null, bool bold = false) => new() { Text = text, FontSize = size, Foreground = new SolidColorBrush(color ?? Colors.White), FontWeight = bold ? FontWeights.SemiBold : FontWeights.Normal, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 0, 0, 8) };
    private static Border Card() => new() { Background = new SolidColorBrush(Color.FromRgb(18, 30, 48)), BorderBrush = new SolidColorBrush(Color.FromRgb(36, 56, 80)), BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(14), Padding = new Thickness(18), Margin = new Thickness(0, 0, 0, 14) };
    private static UIElement SectionTitle(string title) => Text(title, 16, Colors.White, true);
    private static UIElement MetricCard(string title, string value, string detail, string glyph)
    {
        var card = Card(); card.Margin = new Thickness(0, 0, 10, 0); var s = new StackPanel(); s.Children.Add(Text(glyph + "   " + title, 10, Color.FromRgb(151, 174, 198), true)); s.Children.Add(Text(value, 21, Colors.White, true)); s.Children.Add(Text(detail, 11, Color.FromRgb(151, 174, 198))); card.Child = s; return card;
    }
    private static UIElement ActionCard(string title, string detail, Action action)
    {
        var c = Card(); c.Margin = new Thickness(0, 0, 10, 0); var s = new StackPanel(); s.Children.Add(Text(title, 14, Colors.White, true)); s.Children.Add(Text(detail, 11, Color.FromRgb(151, 174, 198))); var b = new Button { Content = "Open", HorizontalAlignment = HorizontalAlignment.Left, Margin = new Thickness(0, 8, 0, 0) }; b.Click += (_, _) => action(); s.Children.Add(b); c.Child = s; return c;
    }
    private static UIElement InfoCard(string title, string value, string secondTitle, string secondValue)
    {
        var c = Card(); var g = new Grid(); g.ColumnDefinitions.Add(new ColumnDefinition()); g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(260) }); var left = new StackPanel(); left.Children.Add(Text(title, 10, Color.FromRgb(151, 174, 198), true)); left.Children.Add(Text(value, 14, Colors.White, true)); var right = new StackPanel(); right.Children.Add(Text(secondTitle, 10, Color.FromRgb(151, 174, 198), true)); right.Children.Add(Text(secondValue, 12, Colors.White)); Grid.SetColumn(right, 1); g.Children.Add(left); g.Children.Add(right); c.Child = g; return c;
    }
    private static Button MakeButton(string label, RoutedEventHandler onClick) { var b = new Button { Content = label, HorizontalAlignment = HorizontalAlignment.Left, Margin = new Thickness(0, 12, 0, 0) }; b.Click += onClick; return b; }
    private static Button MakeAsyncButton(string label, Func<Button, Task> onClick) { var b = new Button { Content = label, HorizontalAlignment = HorizontalAlignment.Left, Margin = new Thickness(0, 12, 0, 0) }; b.Click += async (_, _) => await onClick(b); return b; }
    protected override void OnClosed(EventArgs e) { _timer.Stop(); _monitor.Dispose(); base.OnClosed(e); }

    private void AddPageTitle(string title, string subtitle) { PageTitle.Text = title; PageSubtitle.Text = subtitle; }
}

public sealed class GridLengthAnimation : AnimationTimeline
{
    public override Type TargetPropertyType => typeof(GridLength);
    public GridLength From { get; set; }
    public GridLength To { get; set; }
    public override object GetCurrentValue(object defaultOriginValue, object defaultDestinationValue, AnimationClock animationClock)
    {
        double from = From.Value, to = To.Value, p = animationClock.CurrentProgress ?? 0;
        return new GridLength(from + ((to - from) * p), GridUnitType.Pixel);
    }
    protected override Freezable CreateInstanceCore() => new GridLengthAnimation();
}
