using System.Windows;

namespace BoostPilot;

public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        // The app manifest requests administrator elevation. This check provides a clear diagnostic if policy blocks it.
        if (!Services.AdminService.IsAdministrator())
        {
            MessageBox.Show("BoostPilot needs administrator permission to manage approved Windows settings. Close the app and approve the Windows permission prompt.", "Administrator permission required", MessageBoxButton.OK, MessageBoxImage.Warning);
            Shutdown();
        }
    }
}
