using Microsoft.Win32;
using System.Diagnostics;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace BoostPilot.Services;

public sealed record OptimizationTaskResult(string Name, string Status, string Detail);
public sealed record OptimizationResult(bool Enabled, IReadOnlyList<OptimizationTaskResult> Tasks);

public sealed class OptimizerService
{
    private const string GameBarKey = @"Software\Microsoft\GameBar";
    private const string BackupPathName = "optimizer-backup.json";
    private const string PowerPlanBackupPathName = "optimizer-power-plan.txt";
    private const string HighPerformancePlanGuid = "8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c";

    private sealed class RegistryValueBackup
    {
        public bool Existed { get; set; }
        public string? Value { get; set; }
        public RegistryValueKind Kind { get; set; }
    }

    private string BackupPath => Path.Combine(SettingsStore.DataFolder, BackupPathName);
    private string PowerPlanBackupPath => Path.Combine(SettingsStore.DataFolder, PowerPlanBackupPathName);

    public async Task<OptimizationResult> SetEnabledAsync(
        bool enabled,
        IProgress<(int Percent, string Task)>? progress = null,
        CancellationToken ct = default,
        UserSettings? profile = null)
    {
        if (!AdminService.IsAdministrator())
            throw new InvalidOperationException("Administrator permission is required.");

        var tasks = new List<OptimizationTaskResult>();
        if (enabled)
        {
            progress?.Report((10, "Backing up your current Windows gaming settings"));
            if (!File.Exists(BackupPath)) BackupCurrentValues();
            await Task.Delay(100, ct);

            progress?.Report((40, "Enabling Windows Game Mode preferences"));
            try
            {
                using var key = Registry.CurrentUser.CreateSubKey(GameBarKey, true)
                    ?? throw new InvalidOperationException("Could not open the Windows Game Bar settings key.");
                key.SetValue("AutoGameModeEnabled", 1, RegistryValueKind.DWord);
                key.SetValue("AllowAutoGameMode", 1, RegistryValueKind.DWord);
                tasks.Add(new("Windows Game Mode", "Complete", "Enabled Game Mode preferences for the current Windows user."));
            }
            catch (Exception ex)
            {
                tasks.Add(new("Windows Game Mode", "Failed", ex.Message));
            }

            progress?.Report((65, "Checking the CPU power profile selected in your survey"));
            var powerPlan = ApplyProfilePowerPlan(profile);
            tasks.Add(new("CPU power profile", powerPlan.Status, powerPlan.Detail));

            progress?.Report((85, "Verifying the selected settings"));
            bool gameModeVerified = false;
            try
            {
                using var key = Registry.CurrentUser.OpenSubKey(GameBarKey);
                gameModeVerified = Convert.ToInt32(key?.GetValue("AutoGameModeEnabled", 0)) == 1
                    && Convert.ToInt32(key?.GetValue("AllowAutoGameMode", 0)) == 1;
            }
            catch { }
            tasks.Add(new("Game Mode verification", gameModeVerified ? "Complete" : "Failed",
                gameModeVerified ? "Windows returned the expected values." : "Could not verify both Game Mode values."));

            bool hasFailure = tasks.Any(t => t.Status == "Failed");
            if (hasFailure)
            {
                progress?.Report((92, "A setting did not verify. Restoring the saved settings"));
                var rollback = RestoreSavedSettings();
                tasks.Add(new("Automatic rollback", rollback.Success ? "Complete" : "Failed", rollback.Detail));
                progress?.Report((100, "Finished"));
                return new(!rollback.Success, tasks);
            }

            progress?.Report((100, "Finished"));
            return new(true, tasks);
        }

        progress?.Report((25, "Restoring the saved Windows gaming and CPU power settings"));
        var restore = RestoreSavedSettings();
        tasks.Add(new("Restore previous settings", restore.Success ? "Complete" : "Failed", restore.Detail));
        progress?.Report((100, "Finished"));
        return new(!restore.Success, tasks);
    }

    private (string Status, string Detail) ApplyProfilePowerPlan(UserSettings? profile)
    {
        if (profile is null || !string.Equals(profile.DeviceType, "Desktop PC", StringComparison.OrdinalIgnoreCase))
            return ("Skipped", "No desktop power-plan change: laptop and unknown device profiles keep their current power policy.");

        if (!string.Equals(profile.Goal, "Maximum gaming performance", StringComparison.OrdinalIgnoreCase))
            return ("Skipped", "Your selected profile keeps the current Windows power plan for balanced power use and noise.");

        var plans = RunPowerCfg("/list");
        if (plans.ExitCode != 0 || !plans.Output.Contains(HighPerformancePlanGuid, StringComparison.OrdinalIgnoreCase))
            return ("Skipped", "The built-in High Performance plan is not available on this PC. Your current plan was left unchanged.");

        var active = GetActivePowerPlanGuid();
        if (active is null)
            return ("Skipped", "Could not identify the current Windows power plan, so no power-plan change was made.");
        if (string.Equals(active, HighPerformancePlanGuid, StringComparison.OrdinalIgnoreCase))
            return ("Skipped", "High Performance was already active; BoostPilot left it as it was.");

        Directory.CreateDirectory(SettingsStore.DataFolder);
        bool createdBackup = !File.Exists(PowerPlanBackupPath);
        if (createdBackup)
            File.WriteAllText(PowerPlanBackupPath, active);

        var setResult = RunPowerCfg($"/setactive {HighPerformancePlanGuid}");
        var verified = setResult.ExitCode == 0 && string.Equals(GetActivePowerPlanGuid(), HighPerformancePlanGuid, StringComparison.OrdinalIgnoreCase);
        if (verified)
            return ("Complete", "Enabled the Windows High Performance power plan. This may increase power use and heat; the previous plan is backed up for restoration.");

        // If Windows rejected the change, make a best-effort return to the plan that was active before this attempt.
        var rollback = RunPowerCfg($"/setactive {active}");
        if (rollback.ExitCode == 0 && string.Equals(GetActivePowerPlanGuid(), active, StringComparison.OrdinalIgnoreCase))
        {
            if (createdBackup && File.Exists(PowerPlanBackupPath)) File.Delete(PowerPlanBackupPath);
            return ("Skipped", "Windows did not accept the High Performance plan. The previous power plan remains active.");
        }

        return ("Failed", "Windows did not confirm the High Performance plan, and the previous plan could not be re-verified. Use Settings > System > Power to check the current plan.");
    }

    private (bool Success, string Detail) RestoreSavedSettings()
    {
        bool registryBackupExists = File.Exists(BackupPath);
        bool powerPlanBackupExists = File.Exists(PowerPlanBackupPath);
        if (!registryBackupExists && !powerPlanBackupExists)
            return (false, "No BoostPilot backup was found, so the original settings cannot be confirmed.");

        try
        {
            if (registryBackupExists)
                RestoreRegistryValues();

            if (powerPlanBackupExists)
            {
                var savedGuid = File.ReadAllText(PowerPlanBackupPath).Trim();
                if (!Regex.IsMatch(savedGuid, "^[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}$"))
                    throw new InvalidDataException("The saved Windows power-plan identifier is invalid. The backup has been kept for inspection.");

                var result = RunPowerCfg($"/setactive {savedGuid}");
                if (result.ExitCode != 0 || !string.Equals(GetActivePowerPlanGuid(), savedGuid, StringComparison.OrdinalIgnoreCase))
                    throw new InvalidOperationException("Windows did not confirm that the previous power plan was restored. The backup has been kept so you can retry.");
            }

            if (File.Exists(BackupPath)) File.Delete(BackupPath);
            if (File.Exists(PowerPlanBackupPath)) File.Delete(PowerPlanBackupPath);
            return (true, "Restored the Windows settings and any power plan that BoostPilot changed.");
        }
        catch (Exception ex)
        {
            return (false, ex.Message);
        }
    }

    private void BackupCurrentValues()
    {
        Directory.CreateDirectory(SettingsStore.DataFolder);
        var values = new Dictionary<string, RegistryValueBackup>();
        using var key = Registry.CurrentUser.OpenSubKey(GameBarKey, false);
        foreach (var name in new[] { "AutoGameModeEnabled", "AllowAutoGameMode" })
        {
            bool exists = key?.GetValueNames().Contains(name, StringComparer.OrdinalIgnoreCase) ?? false;
            var kind = exists ? key!.GetValueKind(name) : RegistryValueKind.DWord;
            var raw = exists ? key!.GetValue(name) : null;
            string? stored = !exists ? null : kind switch
            {
                RegistryValueKind.Binary => Convert.ToBase64String((byte[])raw!),
                RegistryValueKind.MultiString => JsonSerializer.Serialize((string[])raw!),
                _ => Convert.ToString(raw, System.Globalization.CultureInfo.InvariantCulture)
            };
            values[name] = new RegistryValueBackup { Existed = exists, Value = stored, Kind = kind };
        }
        File.WriteAllText(BackupPath, JsonSerializer.Serialize(values, new JsonSerializerOptions { WriteIndented = true }));
    }

    private void RestoreRegistryValues()
    {
        var data = JsonSerializer.Deserialize<Dictionary<string, RegistryValueBackup>>(File.ReadAllText(BackupPath)) ?? new();
        using var key = Registry.CurrentUser.CreateSubKey(GameBarKey, true)
            ?? throw new InvalidOperationException("Could not open the Windows Game Bar settings key.");

        foreach (var item in data)
        {
            if (item.Value.Existed)
            {
                object restored = item.Value.Kind switch
                {
                    RegistryValueKind.DWord => int.Parse(item.Value.Value ?? "0", System.Globalization.CultureInfo.InvariantCulture),
                    RegistryValueKind.QWord => long.Parse(item.Value.Value ?? "0", System.Globalization.CultureInfo.InvariantCulture),
                    RegistryValueKind.Binary => Convert.FromBase64String(item.Value.Value ?? ""),
                    RegistryValueKind.MultiString => JsonSerializer.Deserialize<string[]>(item.Value.Value ?? "[]") ?? Array.Empty<string>(),
                    _ => item.Value.Value ?? ""
                };
                key.SetValue(item.Key, restored, item.Value.Kind);
            }
            else
            {
                key.DeleteValue(item.Key, false);
            }
        }
    }

    private static string? GetActivePowerPlanGuid()
    {
        var result = RunPowerCfg("/getactivescheme");
        if (result.ExitCode != 0) return null;
        var match = Regex.Match(result.Output, "[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}");
        return match.Success ? match.Value : null;
    }

    private static (int ExitCode, string Output) RunPowerCfg(string arguments)
    {
        try
        {
            var start = new ProcessStartInfo("powercfg.exe", arguments)
            {
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true
            };
            using var process = Process.Start(start);
            if (process is null) return (-1, "Could not start powercfg.exe.");
            string stdout = process.StandardOutput.ReadToEnd();
            string stderr = process.StandardError.ReadToEnd();
            if (!process.WaitForExit(5000))
            {
                process.Kill(true);
                return (-1, "powercfg.exe timed out.");
            }
            return (process.ExitCode, stdout + Environment.NewLine + stderr);
        }
        catch (Exception ex)
        {
            return (-1, ex.Message);
        }
    }
}
