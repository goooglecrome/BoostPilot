using System.IO;
using System.Text.Json;

namespace BoostPilot.Services;

public sealed class UserSettings
{
    public bool WizardCompleted { get; set; }
    public string DeviceType { get; set; } = "Desktop";
    public string Goal { get; set; } = "Balanced performance";
    public string Games { get; set; } = "";
    public string NetworkType { get; set; } = "Ethernet";
    public string Automation { get; set; } = "Ask before applying changes";
    public bool OptimizerEnabled { get; set; }
}

public static class SettingsStore
{
    private static readonly string Folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "BoostPilot");
    private static readonly string FilePath = Path.Combine(Folder, "settings.json");
    public static string DataFolder => Folder;
    public static UserSettings Load()
    {
        try { if (File.Exists(FilePath)) return JsonSerializer.Deserialize<UserSettings>(File.ReadAllText(FilePath)) ?? new(); }
        catch { }
        return new();
    }
    public static void Save(UserSettings settings)
    {
        Directory.CreateDirectory(Folder);
        var temp = FilePath + ".tmp";
        File.WriteAllText(temp, JsonSerializer.Serialize(settings, new JsonSerializerOptions { WriteIndented = true }));
        File.Move(temp, FilePath, true);
    }
}
