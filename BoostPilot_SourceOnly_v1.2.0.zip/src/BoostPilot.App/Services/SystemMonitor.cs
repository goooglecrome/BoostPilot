using System.Diagnostics;
using System.Management;
using System.Runtime.InteropServices;

namespace BoostPilot.Services;

public sealed record SystemSnapshot(double CpuPercent, double MemoryUsedGb, double MemoryTotalGb, int? RamModuleSpeedMhz, int? CpuMaxClockMhz, string CpuName, string GpuName, string WindowsVersion);

public sealed class SystemMonitor : IDisposable
{
    private PerformanceCounter? _cpu;
    public SystemMonitor() { try { _cpu = new PerformanceCounter("Processor", "% Processor Time", "_Total"); _cpu.NextValue(); } catch { _cpu = null; } }
    public async Task<SystemSnapshot> ReadAsync()
    {
        string cpuName = "Unknown CPU", gpuName = "Unknown GPU";
        int? cpuMaxClock = null, ramModuleSpeed = null;
        await Task.Run(() =>
        {
            try
            {
                using var q = new ManagementObjectSearcher("select Name, MaxClockSpeed from Win32_Processor");
                foreach (ManagementObject x in q.Get())
                {
                    cpuName = x["Name"]?.ToString() ?? cpuName;
                    if (int.TryParse(x["MaxClockSpeed"]?.ToString(), out var clock) && clock > 0) cpuMaxClock = clock;
                    break;
                }
            }
            catch { }
            try { using var q = new ManagementObjectSearcher("select Name from Win32_VideoController"); foreach (ManagementObject x in q.Get()) { gpuName = x["Name"]?.ToString() ?? gpuName; break; } } catch { }
            try
            {
                var speeds = new List<int>();
                using var q = new ManagementObjectSearcher("select Speed from Win32_PhysicalMemory");
                foreach (ManagementObject x in q.Get())
                    if (int.TryParse(x["Speed"]?.ToString(), out var speed) && speed > 0) speeds.Add(speed);
                if (speeds.Count > 0) ramModuleSpeed = speeds.Max();
            }
            catch { }
        });
        var mem = new MemoryStatusEx();
        double total = 0, used = 0;
        if (GlobalMemoryStatusEx(mem)) { total = mem.TotalPhys / 1024d / 1024 / 1024; used = (mem.TotalPhys - mem.AvailPhys) / 1024d / 1024 / 1024; }
        double cpu = 0;
        try { cpu = Math.Clamp(_cpu?.NextValue() ?? 0, 0, 100); } catch { }
        return new(cpu, used, total, ramModuleSpeed, cpuMaxClock, cpuName, gpuName, Environment.OSVersion.VersionString);
    }
    public void Dispose() => _cpu?.Dispose();
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)] private sealed class MemoryStatusEx
    {
        public uint Length = (uint)Marshal.SizeOf<MemoryStatusEx>(); public uint MemoryLoad; public ulong TotalPhys; public ulong AvailPhys; public ulong TotalPageFile; public ulong AvailPageFile; public ulong TotalVirtual; public ulong AvailVirtual; public ulong AvailExtendedVirtual;
    }
    [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)] private static extern bool GlobalMemoryStatusEx([In, Out] MemoryStatusEx lpBuffer);
}
