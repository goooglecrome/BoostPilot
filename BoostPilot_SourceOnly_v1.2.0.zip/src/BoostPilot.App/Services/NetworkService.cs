using System.Net.NetworkInformation;

namespace BoostPilot.Services;

public sealed record PingReport(string Host, int Sent, int Received, double? AverageMs, double? MinMs, double? MaxMs)
{
    public int Lost => Sent - Received;
    public double LossPercent => Sent == 0 ? 0 : Lost * 100d / Sent;
}

public static class NetworkService
{
    public static async Task<PingReport> TestAsync(string host = "1.1.1.1", int count = 5, CancellationToken ct = default)
    {
        using var ping = new Ping(); var times = new List<long>();
        for (int i = 0; i < count; i++)
        {
            ct.ThrowIfCancellationRequested();
            try { var reply = await ping.SendPingAsync(host, 1800); if (reply.Status == IPStatus.Success) times.Add(reply.RoundtripTime); } catch { }
            if (i < count - 1) await Task.Delay(250, ct);
        }
        return new(host, count, times.Count, times.Count == 0 ? null : times.Average(), times.Count == 0 ? null : times.Min(), times.Count == 0 ? null : times.Max());
    }
}
