using System.IO;

namespace BoostPilot.Services;

public sealed record CleanupScan(int Count, double SizeMb);
public sealed record CleanupResult(int Removed, int Skipped, double SizeMb);

public static class CleanupService
{
    private static string TempPath => Path.GetTempPath();
    private static DateTime Cutoff => DateTime.UtcNow.AddDays(-14);

    public static CleanupScan Scan()
    {
        long bytes = 0; int count = 0;
        foreach (var path in EnumerateCandidateFiles())
        {
            try { var info = new FileInfo(path); if (info.LastWriteTimeUtc < Cutoff) { count++; bytes += info.Length; } } catch { }
        }
        return new(count, bytes / 1024d / 1024);
    }

    public static CleanupResult Clean()
    {
        long bytes = 0; int removed = 0, skipped = 0;
        foreach (var path in EnumerateCandidateFiles())
        {
            try
            {
                var info = new FileInfo(path);
                if (info.LastWriteTimeUtc >= Cutoff) continue;
                var length = info.Length; info.IsReadOnly = false; info.Delete(); removed++; bytes += length;
            }
            catch { skipped++; }
        }
        return new(removed, skipped, bytes / 1024d / 1024);
    }

    private static IEnumerable<string> EnumerateCandidateFiles()
    {
        var pending = new Stack<string>();
        pending.Push(TempPath);
        while (pending.Count > 0)
        {
            var current = pending.Pop();
            string[] files;
            try { files = Directory.GetFiles(current, "*", SearchOption.TopDirectoryOnly); }
            catch { files = Array.Empty<string>(); }
            foreach (var file in files) yield return file;

            string[] directories;
            try { directories = Directory.GetDirectories(current, "*", SearchOption.TopDirectoryOnly); }
            catch { directories = Array.Empty<string>(); }
            foreach (var directory in directories)
            {
                try { if ((File.GetAttributes(directory) & FileAttributes.ReparsePoint) == 0) pending.Push(directory); } catch { }
            }
        }
    }
}
