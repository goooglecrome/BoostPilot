using System.Security.Principal;

namespace BoostPilot.Services;

public static class AdminService
{
    public static bool IsAdministrator()
    {
        try { using var identity = WindowsIdentity.GetCurrent(); return new WindowsPrincipal(identity).IsInRole(WindowsBuiltInRole.Administrator); }
        catch { return false; }
    }
}
