; BoostPilot installer. Requires Inno Setup 6.3 or later (https://jrsoftware.org/isdl.php).
; Build with installer\build-installer.cmd, or:  ISCC.exe BoostPilot.iss
;
; Terms & Conditions: bump TermsVersion whenever the terms change. The accepted version and
; date are written to HKCU\Software\BoostPilot\Terms (per-user install) or
; HKLM\Software\BoostPilot\Terms (all-users install).

#define AppName      "BoostPilot"
#define AppVersion   "1.3.1"
#define AppExe       "BoostPilot.exe"
#define TermsVersion "1.0"
#define TermsUrl     "https://getboostpilot.com/terms"
#define PrivacyUrl   "https://getboostpilot.com/privacy-policy"
#ifndef PublishDir
  #define PublishDir "publish"
#endif

[Setup]
; AppId identifies BoostPilot to Windows. Never change it between releases.
AppId={{8E6A4C52-3D1B-4F7A-9B2E-6C0D5A7F1E93}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher=BoostPilot
AppPublisherURL=https://getboostpilot.com
DefaultDirName={autopf}\{#AppName}
DisableProgramGroupPage=yes
; Always show the directory page. With the default (auto), Setup skips it when upgrading an
; existing install, which would let users skip the Terms & Conditions checkbox.
DisableDirPage=no
UsePreviousAppDir=yes
; BoostPilot needs no administrator rights. The user may still choose an all-users install.
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog
; Windows 10 version 1809 or later, and Windows 11. 64-bit only.
MinVersion=10.0.17763
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
WizardStyle=modern
Compression=lzma2
SolidCompression=yes
OutputDir=output
OutputBaseFilename=BoostPilot-Setup-{#AppVersion}
UninstallDisplayIcon={app}\{#AppExe}

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked

[Files]
Source: "{#PublishDir}\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autoprograms}\{#AppName}"; Filename: "{app}\{#AppExe}"
Name: "{autodesktop}\{#AppName}"; Filename: "{app}\{#AppExe}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#AppExe}"; Description: "{cm:LaunchProgram,{#AppName}}"; Flags: nowait postinstall skipifsilent runasoriginaluser

[Registry]
; Written only during the install step, which is reached only after the terms were accepted.
Root: HKA; Subkey: "Software\BoostPilot"; Flags: uninsdeletekeyifempty
Root: HKA; Subkey: "Software\BoostPilot\Terms"; ValueType: string; ValueName: "AcceptedVersion"; ValueData: "{#TermsVersion}"; Flags: uninsdeletekey
Root: HKA; Subkey: "Software\BoostPilot\Terms"; ValueType: string; ValueName: "AcceptedDate"; ValueData: "{code:AcceptedDateValue}"
Root: HKA; Subkey: "Software\BoostPilot\Terms"; ValueType: string; ValueName: "AcceptedVia"; ValueData: "{code:AcceptedViaValue}"

[Code]
const
  TermsUrl = '{#TermsUrl}';
  PrivacyUrl = '{#PrivacyUrl}';

var
  TermsCheck: TNewCheckBox;
  TermsLink, PrivacyLink: TNewStaticText;
  PrevDirEditChange: TNotifyEvent;
  AcceptedAtText, AcceptedViaText: String;
  TermsAccepted: Boolean;

// Local date and time, e.g. 2026-11-26 14:03:09
function Stamp: String;
begin
  Result := GetDateTimeString('yyyy/mm/dd hh:nn:ss', '-', ':');
end;

function AcceptedDateValue(Param: String): String;
begin
  Result := AcceptedAtText;
end;

function AcceptedViaValue(Param: String): String;
begin
  Result := AcceptedViaText;
end;

// Silent installs skip every wizard page, so they must accept explicitly: /ACCEPTTERMS=yes
function InitializeSetup(): Boolean;
begin
  Result := True;
  if WizardSilent then
  begin
    if CompareText(ExpandConstant('{param:ACCEPTTERMS|no}'), 'yes') = 0 then
    begin
      AcceptedAtText := Stamp;
      AcceptedViaText := 'command line (/ACCEPTTERMS=yes)';
      TermsAccepted := True;
    end
    else
    begin
      Log('Silent install refused: pass /ACCEPTTERMS=yes to accept the BoostPilot Terms and Conditions.');
      Result := False;
    end;
  end;
end;

// The one place that decides whether Next is allowed on the directory page.
procedure UpdateNext;
begin
  if WizardForm.CurPageID = wpSelectDir then
    WizardForm.NextButton.Enabled := TermsCheck.Checked and (Trim(WizardForm.DirEdit.Text) <> '');
end;

procedure TermsCheckClick(Sender: TObject);
begin
  if not TermsCheck.Checked then TermsAccepted := False;
  UpdateNext;
end;

// Setup re-enables Next when the folder is edited, so re-apply the gate afterwards.
procedure DirEditChangeHook(Sender: TObject);
begin
  try
    PrevDirEditChange(Sender);
  except
  end;
  UpdateNext;
end;

procedure OpenTerms(Sender: TObject);
var
  Code: Integer;
begin
  ShellExec('open', TermsUrl, '', '', SW_SHOWNORMAL, ewNoWait, Code);
end;

procedure OpenPrivacy(Sender: TObject);
var
  Code: Integer;
begin
  ShellExec('open', PrivacyUrl, '', '', SW_SHOWNORMAL, ewNoWait, Code);
end;

function MakeLink(const Caption: String; Top: Integer; Handler: TNotifyEvent): TNewStaticText;
begin
  Result := TNewStaticText.Create(WizardForm.SelectDirPage);
  Result.Parent := WizardForm.SelectDirPage;
  Result.AutoSize := True;
  Result.Caption := Caption;
  Result.Left := WizardForm.DirEdit.Left + ScaleX(20);
  Result.Top := Top;
  Result.Cursor := crHand;
  Result.Font.Style := [fsUnderline];
  Result.Font.Color := clBlue;
  Result.OnClick := Handler;
end;

procedure InitializeWizard;
var
  Y, Gap, Need: Integer;
begin
  // Make sure there is room between the folder box and the disk-space label.
  Need := ScaleY(84);
  Gap := WizardForm.DiskSpaceLabel.Top - (WizardForm.DirEdit.Top + WizardForm.DirEdit.Height);
  if Gap < Need then
  begin
    WizardForm.Height := WizardForm.Height + (Need - Gap);
    WizardForm.Top := WizardForm.Top - ((Need - Gap) div 2);
  end;
  Y := WizardForm.DirEdit.Top + WizardForm.DirEdit.Height + ScaleY(18);

  TermsCheck := TNewCheckBox.Create(WizardForm.SelectDirPage);
  TermsCheck.Parent := WizardForm.SelectDirPage;
  TermsCheck.Left := WizardForm.DirEdit.Left;
  TermsCheck.Top := Y;
  TermsCheck.Width := WizardForm.DirBrowseButton.Left + WizardForm.DirBrowseButton.Width - TermsCheck.Left;
  TermsCheck.Height := ScaleY(17);
  TermsCheck.Caption := 'I have read and agree to the BoostPilot Terms && Conditions.';
  TermsCheck.Checked := False;            // unchecked by default
  TermsCheck.OnClick := @TermsCheckClick;

  TermsLink := MakeLink('BoostPilot Terms and Conditions', Y + ScaleY(24), @OpenTerms);
  PrivacyLink := MakeLink('BoostPilot Privacy Policy', Y + ScaleY(42), @OpenPrivacy);

  WizardForm.DiskSpaceLabel.Top := Y + ScaleY(66);

  PrevDirEditChange := WizardForm.DirEdit.OnChange;
  WizardForm.DirEdit.OnChange := @DirEditChangeHook;
end;

procedure CurPageChanged(CurPageID: Integer);
begin
  if CurPageID = wpSelectDir then
    UpdateNext;
end;

// Hard enforcement: even if Next were enabled by accident, it cannot proceed unchecked.
function NextButtonClick(CurPageID: Integer): Boolean;
begin
  Result := True;
  if CurPageID = wpSelectDir then
  begin
    if TermsCheck.Checked then
    begin
      AcceptedAtText := Stamp;
      AcceptedViaText := 'installer wizard';
      TermsAccepted := True;
    end
    else
    begin
      MsgBox('You must agree to the BoostPilot Terms and Conditions to continue.', mbInformation, MB_OK);
      Result := False;
    end;
  end;
end;

// Final gate: nothing is copied or registered unless the terms were accepted.
function PrepareToInstall(var NeedsRestart: Boolean): String;
begin
  Result := '';
  if not TermsAccepted then
    Result := 'The BoostPilot Terms and Conditions must be accepted before BoostPilot can be installed.';
end;
