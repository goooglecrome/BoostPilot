# BoostPilot Beta 0.2.0-beta.1

This is the beta track built from the uploaded BoostPilot WPF project. It is separate from the original BoostPilot stable installer and from the old Claude Edition source package.

## Beta-only identity and isolation

- Executable: `BoostPilotBeta.exe`
- Product title: BoostPilot Beta 0.2.0-beta.1
- Install directory: `%LOCALAPPDATA%\\Programs\\BoostPilot Beta`
- Restore database: `%LOCALAPPDATA%\\BoostPilot-Beta\\boostpilot.db`
- Separate Inno Setup AppId and shortcut names
- Published as a GitHub **pre-release**, not as the latest stable release

## Changes in this beta

- Uses current .NET 10 servicing packages (10.0.15) and the latest stable LibreHardwareMonitorLib (0.9.6) checked during this build.
- Replaces the missing `Microsoft.VisualBasic.Devices.ComputerInfo` dependency with the Windows `GlobalMemoryStatusEx` API.
- Explicitly imports `System.IO` for file and drive APIs.
- Separates its SQLite restore database from OG BoostPilot.
- Saves and restores the exact existing per-user StartupApproved registry bytes, rather than trying to reconstruct a prior state from a boolean.
- Rolls back power-plan, startup and allowed registry changes if writing the restore record fails.
- Keeps startup-app disabling and irreversible temporary-file cleanup opt-in by default.
- Keeps changes within the existing safe scope: built-in Windows power plans and a short allow-list of current-user settings. No BIOS, voltage, RAM-timing, Defender, firewall or Windows Update changes.

## Build

The `Build BoostPilot Beta` GitHub Actions workflow extracts the source ZIP, restores packages, publishes a self-contained Windows x64 WPF app, creates a separate installer, uploads a build artifact and publishes a GitHub pre-release.

This project must be tested on real Windows hardware. A successful CI build only confirms compilation and packaging, not that all sensor readings or setting changes work on every PC.
