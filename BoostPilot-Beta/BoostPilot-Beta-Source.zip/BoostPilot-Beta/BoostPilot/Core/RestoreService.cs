using System.IO;
using Microsoft.Data.Sqlite;
namespace BoostPilot.Core;

public record RestoreEntry(long Id, DateTime Time, string Kind, string Target, string OldValue, string Description, bool Undone)
{
    public override string ToString() => $"{Time:g}  {Description}{(Undone ? "  (undone)" : "")}";
}

/// <summary>Records the original value of every change BoostPilot makes, in SQLite, so it can be undone.</summary>
public sealed class RestoreService
{
    readonly string _cs;

    public RestoreService()
    {
        var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "BoostPilot-Beta");
        Directory.CreateDirectory(dir);
        _cs = $"Data Source={Path.Combine(dir, "boostpilot.db")}";
        Run("CREATE TABLE IF NOT EXISTS changes(id INTEGER PRIMARY KEY, time TEXT, kind TEXT, target TEXT, old_value TEXT, description TEXT, undone INTEGER DEFAULT 0)");
    }

    SqliteConnection Open() { var c = new SqliteConnection(_cs); c.Open(); return c; }

    void Run(string sql, params (string, object)[] args)
    {
        using var c = Open(); using var cmd = c.CreateCommand(); cmd.CommandText = sql;
        foreach (var (k, v) in args) cmd.Parameters.AddWithValue(k, v);
        cmd.ExecuteNonQuery();
    }

    public void Record(string kind, string target, string oldValue, string description) =>
        Run("INSERT INTO changes(time,kind,target,old_value,description) VALUES($t,$k,$g,$o,$d)",
            ("$t", DateTime.Now.ToString("o")), ("$k", kind), ("$g", target), ("$o", oldValue), ("$d", description));

    public void MarkUndone(long id) => Run("UPDATE changes SET undone=1 WHERE id=$i", ("$i", id));

    public List<RestoreEntry> List()
    {
        var list = new List<RestoreEntry>();
        using var c = Open(); using var cmd = c.CreateCommand();
        cmd.CommandText = "SELECT id,time,kind,target,old_value,description,undone FROM changes ORDER BY id DESC LIMIT 200";
        using var r = cmd.ExecuteReader();
        while (r.Read())
            list.Add(new(r.GetInt64(0), DateTime.Parse(r.GetString(1)), r.GetString(2), r.GetString(3), r.GetString(4), r.GetString(5), r.GetInt64(6) == 1));
        return list;
    }
}
