using System.Diagnostics;
using System.IO;
using System.Net.NetworkInformation;
using LibreHardwareMonitor.Hardware;

namespace BoostPilot.Core;

public record Snapshot(double Cpu, double RamUsedGb, double RamTotalGb, double DiskFreeGb, double DiskTotalGb,
    double DownKBs, double UpKBs, TimeSpan Uptime, float? CpuTemp, float? GpuTemp, float? GpuLoad, float? CpuClock, float? GpuClock);

/// <summary>Real system readings. Sensor values are null when hardware or permissions do not expose them.</summary>
public sealed class Metrics : IDisposable
{
    readonly PerformanceCounter? _cpu;
    readonly Computer _hw = new() { IsCpuEnabled = true, IsGpuEnabled = true };
    long _rx, _tx;
    DateTime _t = DateTime.UtcNow;

    public Metrics()
    {
        try { _cpu = new PerformanceCounter("Processor Information", "% Processor Utility", "_Total"); _cpu.NextValue(); } catch { }
        try { _hw.Open(); } catch { }
        (_rx, _tx) = Net();
    }

    static (long, long) Net()
    {
        long rx = 0, tx = 0;
        foreach (var n in NetworkInterface.GetAllNetworkInterfaces())
        {
            if (n.OperationalStatus != OperationalStatus.Up || n.NetworkInterfaceType == NetworkInterfaceType.Loopback) continue;
            try { var s = n.GetIPv4Statistics(); rx += s.BytesReceived; tx += s.BytesSent; } catch { /* Some adapters do not expose IPv4 counters. */ }
        }
        return (rx, tx);
    }

    public Snapshot Read()
    {
        var now = DateTime.UtcNow;
        var secs = Math.Max((now - _t).TotalSeconds, 0.001);
        var (rx, tx) = Net();
        var down = Math.Max(0, rx - _rx) / 1024.0 / secs;
        var up = Math.Max(0, tx - _tx) / 1024.0 / secs;
        (_rx, _tx, _t) = (rx, tx, now);

        var (total, free) = WindowsMemory.ReadPhysicalMemory();
        var driveRoot = Path.GetPathRoot(Environment.SystemDirectory) ?? throw new IOException("Could not identify the Windows system drive.");
        var drive = new DriveInfo(driveRoot);

        float? cpuT = null, gpuT = null, gpuL = null, cpuC = null, gpuC = null;
        foreach (var hardware in _hw.Hardware)
        {
            try { hardware.Update(); } catch { continue; }
            var isCpu = hardware.HardwareType == HardwareType.Cpu;
            var isGpu = hardware.HardwareType is HardwareType.GpuNvidia or HardwareType.GpuAmd or HardwareType.GpuIntel;
            foreach (var sensor in hardware.Sensors)
            {
                if (sensor.Value is not float value) continue;
                if (isCpu && sensor.SensorType == SensorType.Temperature && (sensor.Name.Contains("Package", StringComparison.OrdinalIgnoreCase) || sensor.Name.Contains("Tctl", StringComparison.OrdinalIgnoreCase))) cpuT = value;
                if (isCpu && sensor.SensorType == SensorType.Clock && sensor.Name.StartsWith("CPU Core", StringComparison.OrdinalIgnoreCase)) cpuC = Math.Max(cpuC ?? 0, value);
                if (isGpu && sensor.Name.Contains("GPU Core", StringComparison.OrdinalIgnoreCase))
                {
                    if (sensor.SensorType == SensorType.Temperature) gpuT = value;
                    else if (sensor.SensorType == SensorType.Load) gpuL = value;
                    else if (sensor.SensorType == SensorType.Clock) gpuC = value;
                }
            }
        }

        double cpuUsage;
        try { cpuUsage = Math.Clamp(_cpu?.NextValue() ?? 0, 0, 100); } catch { cpuUsage = 0; }
        return new(cpuUsage, total - free, total, drive.AvailableFreeSpace / 1073741824.0, drive.TotalSize / 1073741824.0,
            down, up, TimeSpan.FromMilliseconds(Environment.TickCount64), cpuT, gpuT, gpuL, cpuC, gpuC);
    }

    public static List<string> TopProcesses(int n)
    {
        var list = new List<(string Name, long Bytes)>();
        foreach (var process in Process.GetProcesses())
        {
            try { list.Add((process.ProcessName, process.WorkingSet64)); }
            catch { /* Process may exit or be protected while enumerating. */ }
            finally { process.Dispose(); }
        }
        return list.GroupBy(x => x.Name, StringComparer.OrdinalIgnoreCase)
            .Select(group => (group.Key, group.Sum(x => x.Bytes)))
            .OrderByDescending(x => x.Item2).Take(Math.Max(0, n))
            .Select(x => $"{x.Key}   {x.Item2 / 1048576} MB").ToList();
    }

    public void Dispose()
    {
        _cpu?.Dispose();
        try { _hw.Close(); } catch { }
    }
}
