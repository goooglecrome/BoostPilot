using System.Windows;
namespace BoostPilot;
public partial class App : Application { }
