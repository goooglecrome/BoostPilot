using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;
using BoostPilot.Core;
namespace BoostPilot;

public partial class MainWindow : Window
{
    readonly Metrics _m = new();
    readonly RestoreService _r = new();
    readonly DispatcherTimer _t = new() { Interval = TimeSpan.FromSeconds(1) };
    readonly Queue<double> _cpuHist = new();
    int _tick;

    public MainWindow()
    {
        InitializeComponent();
        _t.Tick += (_, _) => Tick();
        // Monitoring pauses while minimised so the app costs almost nothing in the background.
        StateChanged += (_, _) => { if (WindowState == WindowState.Minimized) _t.Stop(); else _t.Start(); };
        Closed += (_, _) => { _t.Stop(); _m.Dispose(); };
        Loaded += (_, _) =>
        {
            _t.Start(); RefreshStartup(); RefreshRestore(); ShowStep(0); InitGames();
            try { ModeText.Text = $"Active power plan: {PowerPlanManager.Active().Name}"; } catch (Exception ex) { ModeText.Text = ex.Message; }
        };
    }

    static string Fmt(float? v, string unit) => v is float f ? $"{f:F0}{unit}" : "n/a";

    void Tick()
    {
        var s = _m.Read();
        CpuText.Text = $"{s.Cpu:F0}% · {Fmt(s.CpuClock, " MHz")} · {Fmt(s.CpuTemp, " °C")}";
        GpuText.Text = $"{Fmt(s.GpuLoad, "%")} · {Fmt(s.GpuClock, " MHz")} · {Fmt(s.GpuTemp, " °C")}";
        RamText.Text = $"{s.RamUsedGb:F1} / {s.RamTotalGb:F1} GB";
        DiskText.Text = $"{s.DiskFreeGb:F0} GB free of {s.DiskTotalGb:F0} GB";
        NetText.Text = $"↓ {s.DownKBs:F0} KB/s   ↑ {s.UpKBs:F0} KB/s";
        SysText.Text = $"{RuntimeInformation.OSDescription}\nUp {s.Uptime.Days}d {s.Uptime.Hours}h {s.Uptime.Minutes}m";
        _cpuHist.Enqueue(s.Cpu); if (_cpuHist.Count > 60) _cpuHist.Dequeue();
        var pts = new PointCollection(); double w = Graph.ActualWidth, h = Graph.ActualHeight; int i = 0;
        foreach (var v in _cpuHist) pts.Add(new Point(i++ * w / 59, h - v / 100 * h));
        CpuLine.Points = pts;
        if (_tick++ % 5 == 0) ProcText.Text = string.Join("\n", Metrics.TopProcesses(8));
    }

    void Nav_Click(object s, RoutedEventArgs e)
    {
        var t = (string)((FrameworkElement)s).Tag;
        WizPanel.Visibility = t == "wiz" ? Visibility.Visible : Visibility.Collapsed;
        GamePanel.Visibility = t == "game" ? Visibility.Visible : Visibility.Collapsed;
        HwPanel.Visibility = t == "hw" ? Visibility.Visible : Visibility.Collapsed;
        HwActive(t == "hw");
        DashPanel.Visibility = t == "dash" ? Visibility.Visible : Visibility.Collapsed;
        OptPanel.Visibility = t == "opt" ? Visibility.Visible : Visibility.Collapsed;
        RestPanel.Visibility = t == "rest" ? Visibility.Visible : Visibility.Collapsed;
    }

    void Mode_Click(object s, RoutedEventArgs e)
    {
        var (alias, label, what) = (string)((Button)s).Tag switch
        {
            "gaming" => ("SCHEME_MIN", "Gaming", "Switches the Windows power plan to High performance. The CPU stays at higher clocks, which can raise heat, fan noise and battery drain."),
            "saver" => ("SCHEME_MAX", "Power Saving", "Switches to the Power saver plan: lower CPU clocks and shorter idle timers, so heavy tasks may feel slower."),
            _ => ("SCHEME_BALANCED", "Balanced", "Switches to the Balanced plan, the Windows default.")
        };
        if (MessageBox.Show($"{what}\n\nYour current plan is recorded first, so you can undo this in the Restore Centre.", $"Apply {label} mode?", MessageBoxButton.YesNo) != MessageBoxResult.Yes) return;
        try
        {
            var old = PowerPlanManager.Active();
            PowerPlanManager.SetActive(alias);
            var now = PowerPlanManager.Active().Name;
            _r.Record("powerplan", "Windows power plan", old.Guid, $"Power plan {old.Name} → {now} ({label} mode)");
            ModeText.Text = $"Active power plan: {now}";
            RefreshRestore();
        }
        catch (Exception ex) { MessageBox.Show(ex.Message, "Could not apply mode"); }
    }

    void RefreshStartup()
    {
        StartupList.Children.Clear();
        foreach (var i in StartupManager.List())
        {
            var cb = new CheckBox { Content = $"{i.Name}   {i.Command}", IsChecked = i.Enabled, Tag = i.Name, Margin = new Thickness(0, 3, 0, 3), Foreground = Brushes.White };
            cb.Click += Startup_Click;
            StartupList.Children.Add(cb);
        }
        if (StartupList.Children.Count == 0) StartupList.Children.Add(new TextBlock { Text = "No per-user startup apps found." });
    }

    void Startup_Click(object s, RoutedEventArgs e)
    {
        var cb = (CheckBox)s; var name = (string)cb.Tag; bool enable = cb.IsChecked == true;
        var msg = enable ? $"'{name}' will launch again when you sign in."
                         : $"'{name}' will stop launching when you sign in. It is not uninstalled and you can re-enable it any time.";
        if (MessageBox.Show(msg, "Change startup app?", MessageBoxButton.YesNo) != MessageBoxResult.Yes) { cb.IsChecked = !enable; return; }
        try
        {
            _r.Record("startup", name, enable ? "0" : "1", $"Startup app '{name}' {(enable ? "enabled" : "disabled")}");
            StartupManager.SetEnabled(name, enable);
            RefreshRestore();
        }
        catch (Exception ex) { cb.IsChecked = !enable; MessageBox.Show(ex.Message, "Could not change startup app"); }
    }

    void Scan_Click(object s, RoutedEventArgs e)
    {
        var (n, b) = TempCleaner.Scan();
        TempText.Text = $"{n} files older than 24 hours · {b / 1048576.0:F1} MB reclaimable";
    }

    void Clean_Click(object s, RoutedEventArgs e)
    {
        if (MessageBox.Show("Deletes files in your temp folder that are older than 24 hours. Files in use are skipped. Temp files cannot be restored afterwards.", "Clean temporary files?", MessageBoxButton.YesNo) != MessageBoxResult.Yes) return;
        var (n, b) = TempCleaner.Clean();
        TempText.Text = $"Deleted {n} files, freed {b / 1048576.0:F1} MB";
    }

    void RefreshRestore() => RestoreList.ItemsSource = _r.List();

    void Undo_Click(object s, RoutedEventArgs e)
    {
        if (RestoreList.SelectedItem is not RestoreEntry en || en.Undone) return;
        try
        {
            switch (en.Kind)
            {
                case "powerplan": PowerPlanManager.SetActive(en.OldValue); ModeText.Text = $"Active power plan: {PowerPlanManager.Active().Name}"; break;
                case "startup": StartupManager.SetEnabled(en.Target, en.OldValue == "1"); RefreshStartup(); break;
                default: ChangeApplier.Undo(en); break;
            }
            _r.MarkUndone(en.Id); RefreshRestore();
        }
        catch (Exception ex) { MessageBox.Show(ex.Message, "Could not undo"); }
    }
}
