using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using BoostPilot.Core;
namespace BoostPilot;

public record GameRow(GameInfo Game, bool HasProfile, bool Active)
{
    public override string ToString() => $"{Game.Name}   [{Game.Launcher}]   {(Active ? "profile ACTIVE" : HasProfile ? "profile saved" : "no profile")}";
}

public partial class MainWindow
{
    sealed class Session { public required GameInfo Game; public bool Seen; }

    List<GameInfo> _games = new();
    Dictionary<string, List<PlannedChange>> _profiles = new();
    Session? _session; bool _watchBusy, _hwBusy;
    HardwareDetails? _hd;
    readonly DispatcherTimer _watchT = new() { Interval = TimeSpan.FromSeconds(5) };
    readonly DispatcherTimer _hwT = new() { Interval = TimeSpan.FromSeconds(2) };

    void InitGames()
    {
        _watchT.Tick += async (_, _) => await WatchTick();
        _hwT.Tick += async (_, _) => await HwTick();
        Closed += (_, _) => { _watchT.Stop(); _hwT.Stop(); _hd?.Dispose(); };
        // Crash safety: undo anything a previous run left applied for a game session.
        if (!string.IsNullOrEmpty(_r.GetSetting("active_session")))
        {
            var failed = SessionManager.End(_r); RefreshRestore();
            GameStatus.Text = failed == 0 ? "Restored settings that a previous run left applied." : $"{failed} setting(s) from a previous run could not be restored. See the Restore Centre.";
        }
        _watchT.Start();
        _ = ScanGames();
    }

    async Task ScanGames()
    {
        GameStatus.Text = "Scanning Steam and Epic libraries…";
        var found = await Task.Run(GameScanner.Scan);
        var profs = _r.Profiles();
        _profiles = profs.ToDictionary(p => p.Game.Id, p => p.Changes);
        _games = found.Concat(_games).Concat(profs.Select(p => p.Game)).GroupBy(g => g.Id).Select(g => g.First()).OrderBy(g => g.Name).ToList();
        GameStatus.Text = $"{_games.Count} game(s). Steam and Epic are found automatically; use 'Add game' for Xbox, Riot and other launchers.";
        RefreshGames();
    }

    void RefreshGames() => GameList.ItemsSource = _games.Select(g => new GameRow(g, _profiles.ContainsKey(g.Id), _session?.Game.Id == g.Id)).ToList();

    async void ScanGames_Click(object s, RoutedEventArgs e) => await ScanGames();

    void AddGame_Click(object s, RoutedEventArgs e)
    {
        var d = new Microsoft.Win32.OpenFileDialog { Filter = "Game executable (*.exe)|*.exe" };
        if (d.ShowDialog() != true) return;
        var dir = Path.GetDirectoryName(d.FileName)!;
        _games.Add(new GameInfo("manual:" + dir.ToLowerInvariant(), Path.GetFileNameWithoutExtension(d.FileName), "Manual", dir));
        RefreshGames();
    }

    void SmartBoost_Click(object s, RoutedEventArgs e)
    {
        if (GameList.SelectedItem is not GameRow row) { MessageBox.Show("Select a game first."); return; }
        var w = new SmartBoostWindow(row.Game, _r) { Owner = this };
        w.ShowDialog();
        if (!w.Saved) return;
        _r.SaveProfile(row.Game, w.Chosen);
        _profiles[row.Game.Id] = w.Chosen;
        if (w.SessionIds != null)
            _session = new Session { Game = row.Game, Seen = GameWatcher.FindRunning(new[] { row.Game }) != null };
        GameStatus.Text = $"Profile saved for {row.Game.Name}. It applies automatically when the game launches and reverses when it closes. Keep BoostPilot open (minimised is fine).";
        RefreshGames(); RefreshRestore();
        try { ModeText.Text = $"Active power plan: {PowerPlanManager.Active().Name}"; } catch { }
    }

    void RemoveProfile_Click(object s, RoutedEventArgs e)
    {
        if (GameList.SelectedItem is not GameRow row || !row.HasProfile) return;
        _r.DeleteProfile(row.Game.Id); _profiles.Remove(row.Game.Id);
        if (_session?.Game.Id == row.Game.Id) EndSession();
        RefreshGames();
    }

    void EndSession_Click(object s, RoutedEventArgs e)
    {
        if (_session == null && string.IsNullOrEmpty(_r.GetSetting("active_session"))) { GameStatus.Text = "No game profile is currently applied."; return; }
        EndSession();
    }

    async Task WatchTick()
    {
        if (_watchBusy || (_profiles.Count == 0 && _session == null)) return;
        _watchBusy = true;
        try
        {
            var watch = _games.Where(g => _profiles.ContainsKey(g.Id)).ToList();
            var running = await Task.Run(() => GameWatcher.FindRunning(watch));
            if (running != null && _session == null)
            {
                var log = new List<string>();
                await Task.Run(() => SessionManager.Start(_profiles[running.Id], _r, log));
                _session = new Session { Game = running, Seen = true };
                GameStatus.Text = $"{running.Name} launched: {log.Count(l => l.StartsWith("Done"))} change(s) applied. Normal settings return when it closes.";
                RefreshGames(); RefreshRestore();
            }
            else if (_session != null && running?.Id == _session.Game.Id) _session.Seen = true;
            else if (_session != null && _session.Seen) EndSession();
        }
        catch (Exception ex) { GameStatus.Text = ex.Message; }
        finally { _watchBusy = false; }
    }

    void EndSession()
    {
        var name = _session?.Game.Name ?? "Game";
        var failed = SessionManager.End(_r); _session = null;
        GameStatus.Text = failed == 0 ? $"{name} closed. Normal settings restored." : $"{failed} setting(s) couldn't be restored automatically. Use the Restore Centre.";
        RefreshGames(); RefreshRestore();
        try { ModeText.Text = $"Active power plan: {PowerPlanManager.Active().Name}"; } catch { }
    }

    // The detailed hardware screen only polls while it is visible.
    void HwActive(bool on) { if (on) { _hwT.Start(); _ = HwTick(); } else _hwT.Stop(); }

    async Task HwTick()
    {
        if (_hwBusy) return; _hwBusy = true;
        try { var lines = await Task.Run(() => (_hd ??= new HardwareDetails()).Read()); HwText.Text = string.Join("\n", lines); }
        catch (Exception ex) { HwText.Text = ex.Message; }
        finally { _hwBusy = false; }
    }
}
