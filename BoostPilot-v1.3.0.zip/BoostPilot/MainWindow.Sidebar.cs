using System.Windows;
using System.Windows.Input;
using System.Windows.Media.Animation;
namespace BoostPilot;

public partial class MainWindow
{
    const double SidebarCollapsed = 64, SidebarExpanded = 232;

    // The sidebar floats over the page, so the content never reflows while it opens or closes.
    void Sidebar_Enter(object s, MouseEventArgs e) => AnimateSidebar(SidebarExpanded);
    void Sidebar_Leave(object s, MouseEventArgs e) => AnimateSidebar(SidebarCollapsed);

    void AnimateSidebar(double to) =>
        Sidebar.BeginAnimation(FrameworkElement.WidthProperty,
            new DoubleAnimation(to, TimeSpan.FromMilliseconds(180)) { EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut } });
}
