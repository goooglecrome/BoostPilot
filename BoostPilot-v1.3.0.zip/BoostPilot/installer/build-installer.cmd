@echo off
setlocal
cd /d "%~dp0"
echo Publishing BoostPilot (self-contained, win-x64)...
dotnet publish ..\BoostPilot.csproj -c Release -r win-x64 --self-contained true -o publish
if errorlevel 1 exit /b 1
set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" (
  echo Inno Setup 6.3 or later is required: https://jrsoftware.org/isdl.php
  exit /b 1
)
"%ISCC%" BoostPilot.iss
if errorlevel 1 exit /b 1
echo Done. The installer is in installer\output
