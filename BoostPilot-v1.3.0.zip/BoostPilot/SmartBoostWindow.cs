using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using BoostPilot.Core;
namespace BoostPilot;

/// <summary>Smart Boost: inspect this PC, recommend safe settings for one game, show every change, then apply with progress.</summary>
public sealed class SmartBoostWindow : Window
{
    readonly GameInfo _game; readonly RestoreService _r;
    readonly StackPanel _body = new() { Margin = new Thickness(0, 0, 8, 0) };
    readonly ProgressBar _bar = new() { Height = 8, Margin = new Thickness(0, 10, 0, 0), Visibility = Visibility.Collapsed, Foreground = new SolidColorBrush(Color.FromRgb(0x56, 0xFB, 0x1A)) };
    readonly Button _applyNow = Btn("Apply now and save profile"), _saveOnly = Btn("Save profile only"), _close = Btn("Cancel");
    List<PlannedChange> _plan = new();
    public List<PlannedChange> Chosen { get; } = new();
    public List<long>? SessionIds { get; private set; }
    public bool Saved { get; private set; }

    static Button Btn(string t) => new() { Content = t, Padding = new Thickness(14, 8, 14, 8), Margin = new Thickness(0, 0, 8, 0), Background = new SolidColorBrush(Color.FromRgb(0x14, 0x14, 0x14)), Foreground = Brushes.White };

    static TextBlock T(string s, bool dim = false, double top = 6)
    {
        var tb = new TextBlock { Text = s, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, top, 0, 0) };
        if (dim) tb.Foreground = new SolidColorBrush(Color.FromRgb(0x8A, 0x90, 0x99));
        return tb;
    }

    public SmartBoostWindow(GameInfo game, RestoreService r)
    {
        _game = game; _r = r;
        Title = $"Smart Boost: {game.Name}"; Width = 640; Height = 620; WindowStartupLocation = WindowStartupLocation.CenterOwner;
        Background = new SolidColorBrush(Color.FromRgb(0x05, 0x05, 0x05)); Foreground = Brushes.White; FontFamily = new FontFamily("Segoe UI");
        var buttons = new WrapPanel { Margin = new Thickness(0, 12, 0, 0) };
        buttons.Children.Add(_applyNow); buttons.Children.Add(_saveOnly); buttons.Children.Add(_close);
        var dock = new DockPanel { Margin = new Thickness(18) };
        DockPanel.SetDock(buttons, Dock.Bottom); DockPanel.SetDock(_bar, Dock.Bottom);
        dock.Children.Add(buttons); dock.Children.Add(_bar); dock.Children.Add(new ScrollViewer { Content = _body });
        Content = dock;
        _applyNow.IsEnabled = _saveOnly.IsEnabled = false;
        _applyNow.Click += async (_, _) => await Finish(true);
        _saveOnly.Click += async (_, _) => await Finish(false);
        _close.Click += (_, _) => Close();
        Loaded += async (_, _) => await Inspect();
    }

    async Task Inspect()
    {
        _body.Children.Add(T("Inspecting your PC…", true));
        var (hw, plan, top) = await Task.Run(() =>
        {
            var h = HardwareScanner.Scan();
            return (h, WizardPlanner.Build(Goal.CompetitiveGaming, h), Metrics.TopProcesses(5));
        });
        _plan = plan.Changes.Where(c => c.Kind is "powerplan" or "regdword").ToList();
        foreach (var c in _plan) if (c.Target.Contains("EnableTransparency")) c.Selected = false;   // optional, off by default
        if (!_plan.Any(c => c.Kind == "powerplan") && !(hw.IsLaptop && hw.OnBattery))
            _plan.Insert(0, new() { Title = "Use the High performance power plan while this game runs", Kind = "powerplan", Target = "SCHEME_MIN", Selected = true,
                Explain = "Keeps the CPU at higher clocks. Your current plan is restored when the game closes." });

        _body.Children.Clear();
        _body.Children.Add(T($"{hw.Cpu} · {hw.RamGb:F0} GB RAM · {hw.Gpu} · {(hw.IsLaptop ? "laptop" : "desktop")}"));
        foreach (var a in plan.Advice) _body.Children.Add(T("Note: " + a, true));
        _body.Children.Add(T("Recommended changes for this game. Untick anything you don't want:", false, 14));
        foreach (var c in _plan)
        {
            var cb = new CheckBox { Content = c.Title, IsChecked = c.Selected, Margin = new Thickness(0, 12, 0, 0), Foreground = Brushes.White, FontWeight = FontWeights.SemiBold };
            cb.Click += (_, _) => c.Selected = cb.IsChecked == true;
            var note = T(c.Explain, true, 2); note.Margin = new Thickness(22, 2, 0, 0);
            _body.Children.Add(cb); _body.Children.Add(note);
        }
        _body.Children.Add(T("Heaviest background apps right now: " + string.Join(", ", top) + ". BoostPilot never closes apps for you; close what you don't need.", true, 14));
        _applyNow.IsEnabled = _saveOnly.IsEnabled = _plan.Count > 0;
    }

    async Task Finish(bool applyNow)
    {
        Chosen.AddRange(_plan.Where(c => c.Selected));
        if (Chosen.Count == 0) { MessageBox.Show(this, "Nothing is ticked, so there is nothing to save."); return; }
        _applyNow.IsEnabled = _saveOnly.IsEnabled = false; Saved = true;
        if (!applyNow) { Close(); return; }

        _bar.Visibility = Visibility.Visible; _bar.Maximum = Chosen.Count; _body.Children.Clear();
        var stepText = T("Starting…"); _body.Children.Add(stepText);
        IProgress<(int, string)> prog = new Progress<(int, string)>(p => { _bar.Value = p.Item1; stepText.Text = p.Item2; });
        var log = new List<string>();
        SessionIds = await Task.Run(() => SessionManager.Start(Chosen, _r, log, (i, t) => prog.Report((i, t))));
        _bar.Value = _bar.Maximum; _body.Children.Clear();
        foreach (var l in log) _body.Children.Add(T(l));
        _body.Children.Add(T("Settings return to normal when the game closes, or use 'Restore normal settings now' on the Games screen.", true, 14));
        _close.Content = "Done";
    }
}
