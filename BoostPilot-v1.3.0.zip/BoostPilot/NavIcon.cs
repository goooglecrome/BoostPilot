using System.Windows;
using System.Windows.Media;
namespace BoostPilot;

/// <summary>Attached property that gives each sidebar item its icon outline.</summary>
public static class NavIcon
{
    public static readonly DependencyProperty DataProperty = DependencyProperty.RegisterAttached("Data", typeof(Geometry), typeof(NavIcon));
    public static Geometry? GetData(DependencyObject o) => (Geometry?)o.GetValue(DataProperty);
    public static void SetData(DependencyObject o, Geometry? v) => o.SetValue(DataProperty, v);
}
