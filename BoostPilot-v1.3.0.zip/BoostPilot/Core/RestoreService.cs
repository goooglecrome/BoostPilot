using System.Text.Json;
using Microsoft.Data.Sqlite;
namespace BoostPilot.Core;

public record RestoreEntry(long Id, DateTime Time, string Kind, string Target, string OldValue, string Description, bool Undone)
{
    public override string ToString() => $"{Time:g}  {Description}{(Undone ? "  (undone)" : "")}";
}

/// <summary>Records the original value of every change BoostPilot makes, in SQLite, so it can be undone.</summary>
public sealed class RestoreService
{
    readonly string _cs;

    public RestoreService()
    {
        var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "BoostPilot");
        Directory.CreateDirectory(dir);
        _cs = $"Data Source={Path.Combine(dir, "boostpilot.db")}";
        Run("CREATE TABLE IF NOT EXISTS profiles(game_id TEXT PRIMARY KEY, game_json TEXT, changes_json TEXT)");
        Run("CREATE TABLE IF NOT EXISTS kv(k TEXT PRIMARY KEY, v TEXT)");
        Run("CREATE TABLE IF NOT EXISTS changes(id INTEGER PRIMARY KEY, time TEXT, kind TEXT, target TEXT, old_value TEXT, description TEXT, undone INTEGER DEFAULT 0)");
    }

    SqliteConnection Open() { var c = new SqliteConnection(_cs); c.Open(); return c; }

    void Run(string sql, params (string, object)[] args)
    {
        using var c = Open(); using var cmd = c.CreateCommand(); cmd.CommandText = sql;
        foreach (var (k, v) in args) cmd.Parameters.AddWithValue(k, v);
        cmd.ExecuteNonQuery();
    }

    public void Record(string kind, string target, string oldValue, string description) =>
        Run("INSERT INTO changes(time,kind,target,old_value,description) VALUES($t,$k,$g,$o,$d)",
            ("$t", DateTime.Now.ToString("o")), ("$k", kind), ("$g", target), ("$o", oldValue), ("$d", description));

    public void SaveProfile(GameInfo g, List<PlannedChange> changes) =>
        Run("INSERT OR REPLACE INTO profiles(game_id,game_json,changes_json) VALUES($i,$g,$c)",
            ("$i", g.Id), ("$g", JsonSerializer.Serialize(g)), ("$c", JsonSerializer.Serialize(changes)));

    public void DeleteProfile(string id) => Run("DELETE FROM profiles WHERE game_id=$i", ("$i", id));

    public List<(GameInfo Game, List<PlannedChange> Changes)> Profiles()
    {
        var l = new List<(GameInfo, List<PlannedChange>)>();
        using var c = Open(); using var cmd = c.CreateCommand();
        cmd.CommandText = "SELECT game_json, changes_json FROM profiles";
        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            var g = JsonSerializer.Deserialize<GameInfo>(rd.GetString(0));
            var ch = JsonSerializer.Deserialize<List<PlannedChange>>(rd.GetString(1));
            if (g != null && ch != null) l.Add((g, ch));
        }
        return l;
    }

    public string? GetSetting(string k)
    {
        using var c = Open(); using var cmd = c.CreateCommand();
        cmd.CommandText = "SELECT v FROM kv WHERE k=$k"; cmd.Parameters.AddWithValue("$k", k);
        return cmd.ExecuteScalar() as string;
    }

    public void SetSetting(string k, string v) => Run("INSERT OR REPLACE INTO kv(k,v) VALUES($k,$v)", ("$k", k), ("$v", v));

    public void MarkUndone(long id) => Run("UPDATE changes SET undone=1 WHERE id=$i", ("$i", id));

    public List<RestoreEntry> List()
    {
        var list = new List<RestoreEntry>();
        using var c = Open(); using var cmd = c.CreateCommand();
        cmd.CommandText = "SELECT id,time,kind,target,old_value,description,undone FROM changes ORDER BY id DESC LIMIT 200";
        using var r = cmd.ExecuteReader();
        while (r.Read())
            list.Add(new(r.GetInt64(0), DateTime.Parse(r.GetString(1)), r.GetString(2), r.GetString(3), r.GetString(4), r.GetString(5), r.GetInt64(6) == 1));
        return list;
    }
}
