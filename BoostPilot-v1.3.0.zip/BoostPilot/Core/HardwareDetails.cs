using LibreHardwareMonitor.Hardware;
namespace BoostPilot.Core;

/// <summary>Detailed sensor readout. Lists only what this PC's hardware (and the current permissions) actually expose.</summary>
public sealed class HardwareDetails : IDisposable
{
    readonly Computer _c = new() { IsCpuEnabled = true, IsGpuEnabled = true, IsMotherboardEnabled = true, IsStorageEnabled = true, IsBatteryEnabled = true };

    public HardwareDetails() { try { _c.Open(); } catch { } }

    public List<string> Read()
    {
        var lines = new List<string>();
        foreach (var h in _c.Hardware) Add(h, lines);
        if (lines.Count == 0) lines.Add("No sensors are exposed right now. Try running BoostPilot as administrator.");
        return lines;
    }

    static string Unit(SensorType t) => t switch
    {
        SensorType.Load or SensorType.Level => "%", SensorType.Temperature => "°C", SensorType.Fan => "RPM",
        SensorType.SmallData => "MB", SensorType.Energy => "mWh", _ => ""
    };

    static void Add(IHardware h, List<string> o)
    {
        h.Update();
        var rows = new List<string>();
        foreach (var s in h.Sensors)
        {
            if (s.Value is not float v) continue;
            bool keep = s.SensorType switch
            {
                SensorType.Load => s.Name.StartsWith("CPU Core #") || s.Name == "GPU Core",   // per-core CPU usage
                SensorType.Temperature or SensorType.Fan => true,                               // CPU/GPU/drive temps, fan speeds
                SensorType.SmallData => s.Name.StartsWith("GPU Memory"),                        // VRAM used/total
                SensorType.Energy or SensorType.Level => h.HardwareType == HardwareType.Battery,
                _ => false
            };
            if (keep) rows.Add($"   {s.Name}: {v:F1} {Unit(s.SensorType)}");
        }
        if (h.HardwareType == HardwareType.Battery)
        {
            float? Get(string n) => h.Sensors.FirstOrDefault(x => x.Name == n)?.Value;
            var des = Get("Designed Capacity"); var full = Get("Full Charged Capacity");
            if (des > 0 && full != null) rows.Add($"   Health: {full.Value / des.Value * 100:F0} % of design capacity");
        }
        if (rows.Count > 0) { o.Add($"{h.Name}  ({h.HardwareType})"); o.AddRange(rows); }
        foreach (var sub in h.SubHardware) Add(sub, o);
    }

    public void Dispose() { try { _c.Close(); } catch { } }
}
