using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using Microsoft.Win32;
namespace BoostPilot.Core;

public record GameInfo(string Id, string Name, string Launcher, string InstallDir);

/// <summary>Finds installed Steam and Epic games from their own manifest files.</summary>
public static class GameScanner
{
    public static List<GameInfo> Scan()
    {
        var l = new List<GameInfo>();
        try { l.AddRange(Steam()); } catch { }
        try { l.AddRange(Epic()); } catch { }
        return l.GroupBy(g => g.Id).Select(g => g.First()).OrderBy(g => g.Name).ToList();
    }

    static IEnumerable<GameInfo> Steam()
    {
        var root = Registry.CurrentUser.OpenSubKey(@"Software\Valve\Steam")?.GetValue("SteamPath") as string;
        if (root == null) yield break;
        var libs = new List<string> { root };
        var vdf = Path.Combine(root, "steamapps", "libraryfolders.vdf");
        if (File.Exists(vdf))
            foreach (Match m in Regex.Matches(File.ReadAllText(vdf), "\"path\"\\s+\"([^\"]+)\""))
                libs.Add(m.Groups[1].Value.Replace(@"\\", @"\"));
        foreach (var lib in libs.Select(x => x.Replace('/', '\\')).Distinct(StringComparer.OrdinalIgnoreCase))
        {
            var apps = Path.Combine(lib, "steamapps");
            if (!Directory.Exists(apps)) continue;
            foreach (var f in Directory.EnumerateFiles(apps, "appmanifest_*.acf"))
            {
                var t = File.ReadAllText(f);
                string? V(string k) { var m = Regex.Match(t, "\"" + k + "\"\\s+\"([^\"]*)\""); return m.Success ? m.Groups[1].Value : null; }
                var id = V("appid"); var name = V("name"); var dir = V("installdir");
                if (id == null || name == null || dir == null) continue;
                if (name.Contains("Redistributable") || name.StartsWith("Steamworks")) continue;
                var full = Path.Combine(apps, "common", dir);
                if (Directory.Exists(full)) yield return new($"steam:{id}", name, "Steam", full);
            }
        }
    }

    static IEnumerable<GameInfo> Epic()
    {
        var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "Epic", "EpicGamesLauncher", "Data", "Manifests");
        if (!Directory.Exists(dir)) yield break;
        foreach (var f in Directory.EnumerateFiles(dir, "*.item"))
        {
            using var doc = JsonDocument.Parse(File.ReadAllText(f));
            var r = doc.RootElement;
            if (r.TryGetProperty("DisplayName", out var n) && r.TryGetProperty("InstallLocation", out var l) && r.TryGetProperty("CatalogItemId", out var id)
                && l.GetString() is string loc && Directory.Exists(loc))
                yield return new($"epic:{id.GetString()}", n.GetString() ?? "Epic game", "Epic", loc);
        }
    }
}

/// <summary>Detects a running game by checking whether any process runs from the game's install folder.</summary>
public static class GameWatcher
{
    [DllImport("kernel32.dll", SetLastError = true)] static extern IntPtr OpenProcess(uint access, bool inherit, int pid);
    [DllImport("kernel32.dll", SetLastError = true)] static extern bool QueryFullProcessImageName(IntPtr h, uint flags, StringBuilder sb, ref int size);
    [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr h);

    static string? PathOf(int pid)
    {
        var h = OpenProcess(0x1000 /* PROCESS_QUERY_LIMITED_INFORMATION */, false, pid);
        if (h == IntPtr.Zero) return null;
        try { var sb = new StringBuilder(1024); int n = sb.Capacity; return QueryFullProcessImageName(h, 0, sb, ref n) ? sb.ToString() : null; }
        finally { CloseHandle(h); }
    }

    public static GameInfo? FindRunning(IReadOnlyCollection<GameInfo> games)
    {
        if (games.Count == 0) return null;
        foreach (var p in Process.GetProcesses())
        {
            try
            {
                var path = PathOf(p.Id);
                if (path == null) continue;
                foreach (var g in games)
                    if (path.StartsWith(g.InstallDir.TrimEnd('\\') + "\\", StringComparison.OrdinalIgnoreCase)) return g;
            }
            finally { p.Dispose(); }
        }
        return null;
    }
}

/// <summary>Applies a set of changes as one "session" and later reverses exactly those changes.</summary>
public static class SessionManager
{
    public static List<long> Start(IEnumerable<PlannedChange> changes, RestoreService r, List<string> log, Action<int, string>? progress = null)
    {
        var list = changes.ToList();
        long before = r.List().Select(x => x.Id).DefaultIfEmpty(0).Max();
        for (int i = 0; i < list.Count; i++)
        {
            progress?.Invoke(i, $"Applying: {list[i].Title} ({i + 1}/{list.Count})");
            try { log.Add("Done: " + ChangeApplier.Apply(list[i], r)); }
            catch (Exception ex) { log.Add($"Failed: {list[i].Title}: {ex.Message}"); }
        }
        progress?.Invoke(list.Count, "Finished");
        var ids = r.List().Where(x => x.Id > before && !x.Undone).Select(x => x.Id).ToList();
        r.SetSetting("active_session", string.Join(",", ids));   // survives a crash: restored on next start
        return ids;
    }

    /// <returns>How many changes could not be reversed (they stay in the Restore Centre).</returns>
    public static int End(RestoreService r)
    {
        var ids = (r.GetSetting("active_session") ?? "").Split(',', StringSplitOptions.RemoveEmptyEntries).Select(s => long.Parse(s)).ToHashSet();
        int failed = 0;
        foreach (var e in r.List().Where(y => ids.Contains(y.Id) && !y.Undone).OrderByDescending(y => y.Id).ToList())
        {
            try
            {
                switch (e.Kind)
                {
                    case "powerplan": PowerPlanManager.SetActive(e.OldValue); break;
                    case "startup": StartupManager.SetEnabled(e.Target, e.OldValue == "1"); break;
                    default: ChangeApplier.Undo(e); break;
                }
                r.MarkUndone(e.Id);
            }
            catch { failed++; }
        }
        r.SetSetting("active_session", "");
        return failed;
    }
}
