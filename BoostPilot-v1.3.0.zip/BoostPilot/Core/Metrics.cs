using System.Diagnostics;
using System.Net.NetworkInformation;
using LibreHardwareMonitor.Hardware;
namespace BoostPilot.Core;

public record Snapshot(double Cpu, double RamUsedGb, double RamTotalGb, double DiskFreeGb, double DiskTotalGb,
    double DownKBs, double UpKBs, TimeSpan Uptime, float? CpuTemp, float? GpuTemp, float? GpuLoad, float? CpuClock, float? GpuClock);

/// <summary>Real system readings. Sensor values are null when the hardware or permissions don't expose them (CPU temps usually need admin).</summary>
public sealed class Metrics : IDisposable
{
    readonly PerformanceCounter? _cpu;
    readonly Computer _hw = new() { IsCpuEnabled = true, IsGpuEnabled = true };
    long _rx, _tx; DateTime _t = DateTime.UtcNow;

    public Metrics()
    {
        try { _cpu = new PerformanceCounter("Processor Information", "% Processor Utility", "_Total"); _cpu.NextValue(); } catch { }
        try { _hw.Open(); } catch { }
        (_rx, _tx) = Net();
    }

    static (long, long) Net()
    {
        long rx = 0, tx = 0;
        foreach (var n in NetworkInterface.GetAllNetworkInterfaces())
        {
            if (n.OperationalStatus != OperationalStatus.Up || n.NetworkInterfaceType == NetworkInterfaceType.Loopback) continue;
            var s = n.GetIPv4Statistics(); rx += s.BytesReceived; tx += s.BytesSent;
        }
        return (rx, tx);
    }

    public Snapshot Read()
    {
        var now = DateTime.UtcNow; var secs = Math.Max((now - _t).TotalSeconds, 0.001);
        var (rx, tx) = Net();
        double down = (rx - _rx) / 1024.0 / secs, up = (tx - _tx) / 1024.0 / secs;
        (_rx, _tx, _t) = (rx, tx, now);

        var ci = new Microsoft.VisualBasic.Devices.ComputerInfo();
        double total = ci.TotalPhysicalMemory / 1073741824.0, free = ci.AvailablePhysicalMemory / 1073741824.0;
        var d = new DriveInfo(Path.GetPathRoot(Environment.SystemDirectory)!);

        float? cpuT = null, gpuT = null, gpuL = null, cpuC = null, gpuC = null;
        foreach (var h in _hw.Hardware)
        {
            h.Update();
            bool cpu = h.HardwareType == HardwareType.Cpu;
            bool gpu = h.HardwareType is HardwareType.GpuNvidia or HardwareType.GpuAmd or HardwareType.GpuIntel;
            foreach (var s in h.Sensors)
            {
                if (s.Value is not float v) continue;
                if (cpu && s.SensorType == SensorType.Temperature && (s.Name.Contains("Package") || s.Name.Contains("Tctl"))) cpuT = v;
                if (cpu && s.SensorType == SensorType.Clock && s.Name.StartsWith("CPU Core")) cpuC = Math.Max(cpuC ?? 0, v);
                if (gpu && s.Name == "GPU Core")
                {
                    if (s.SensorType == SensorType.Temperature) gpuT = v;
                    else if (s.SensorType == SensorType.Load) gpuL = v;
                    else if (s.SensorType == SensorType.Clock) gpuC = v;
                }
            }
        }
        return new(Math.Min(_cpu?.NextValue() ?? 0, 100), total - free, total, d.AvailableFreeSpace / 1073741824.0, d.TotalSize / 1073741824.0,
            down, up, TimeSpan.FromMilliseconds(Environment.TickCount64), cpuT, gpuT, gpuL, cpuC, gpuC);
    }

    public static List<string> TopProcesses(int n)
    {
        var l = new List<(string, long)>();
        foreach (var p in Process.GetProcesses()) { try { l.Add((p.ProcessName, p.WorkingSet64)); } catch { } finally { p.Dispose(); } }
        return l.GroupBy(x => x.Item1).Select(g => (g.Key, g.Sum(x => x.Item2))).OrderByDescending(x => x.Item2).Take(n)
                .Select(x => $"{x.Key}   {x.Item2 / 1048576} MB").ToList();
    }

    public void Dispose() { _cpu?.Dispose(); try { _hw.Close(); } catch { } }
}
