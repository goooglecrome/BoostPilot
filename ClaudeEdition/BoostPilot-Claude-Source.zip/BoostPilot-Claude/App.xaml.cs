using System.Windows;
namespace BoostPilotClaude;
public partial class App : Application { }
