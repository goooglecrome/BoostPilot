using System.Diagnostics;
using System.Text.RegularExpressions;
using Microsoft.Win32;
namespace BoostPilotClaude.Core;

/// <summary>Switches the Windows power plan through the built-in powercfg tool (no admin needed).</summary>
public static class PowerPlanManager
{
    public static (string Guid, string Name) Active()
    {
        var (_, o) = Powercfg("/getactivescheme");
        var m = Regex.Match(o, @"([0-9a-fA-F]{8}-(?:[0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12})\s*\((.+?)\)");
        return m.Success ? (m.Groups[1].Value, m.Groups[2].Value) : throw new InvalidOperationException("Could not read the active power plan.");
    }

    public static void SetActive(string schemeOrGuid)
    {
        var (code, o) = Powercfg($"/setactive {schemeOrGuid}");
        if (code != 0) throw new InvalidOperationException($"Windows refused the power plan change (this plan may not exist on this PC): {o.Trim()}");
    }

    static (int, string) Powercfg(string args)
    {
        using var p = Process.Start(new ProcessStartInfo("powercfg", args)
        { RedirectStandardOutput = true, RedirectStandardError = true, UseShellExecute = false, CreateNoWindow = true })!;
        var o = p.StandardOutput.ReadToEnd() + p.StandardError.ReadToEnd();
        p.WaitForExit();
        return (p.ExitCode, o);
    }
}

public record StartupItem(string Name, string Command, bool Enabled);

/// <summary>Lists and toggles per-user startup apps using the same StartupApproved flags Task Manager uses. Nothing is deleted.</summary>
public static class StartupManager
{
    const string RunKey = @"Software\Microsoft\Windows\CurrentVersion\Run";
    const string ApprovedKey = @"Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run";

    public static List<StartupItem> List()
    {
        var list = new List<StartupItem>();
        using var run = Registry.CurrentUser.OpenSubKey(RunKey);
        using var ap = Registry.CurrentUser.OpenSubKey(ApprovedKey);
        if (run == null) return list;
        foreach (var n in run.GetValueNames())
        {
            var enabled = !(ap?.GetValue(n) is byte[] b && b.Length > 0 && (b[0] & 1) == 1);
            list.Add(new(n, run.GetValue(n)?.ToString() ?? "", enabled));
        }
        return list;
    }

    public static void SetEnabled(string name, bool enabled)
    {
        using var k = Registry.CurrentUser.CreateSubKey(ApprovedKey);
        var data = new byte[12];
        data[0] = enabled ? (byte)2 : (byte)3;
        if (!enabled) BitConverter.GetBytes(DateTime.UtcNow.ToFileTimeUtc()).CopyTo(data, 4);
        k.SetValue(name, data, RegistryValueKind.Binary);
    }
}

/// <summary>Scans and deletes files in the user's temp folder that are older than 24 hours.</summary>
public static class TempCleaner
{
    static readonly EnumerationOptions Opt = new() { RecurseSubdirectories = true, IgnoreInaccessible = true, AttributesToSkip = FileAttributes.ReparsePoint };

    static IEnumerable<FileInfo> Old() =>
        new DirectoryInfo(Path.GetTempPath()).EnumerateFiles("*", Opt).Where(f => f.LastWriteTimeUtc < DateTime.UtcNow.AddHours(-24));

    public static (int Files, long Bytes) Scan() { int n = 0; long b = 0; foreach (var f in Old()) { n++; b += f.Length; } return (n, b); }

    public static (int Deleted, long Bytes) Clean()
    {
        int n = 0; long b = 0;
        foreach (var f in Old().ToList()) { try { var len = f.Length; f.Delete(); n++; b += len; } catch { /* in use: skip */ } }
        return (n, b);
    }
}
