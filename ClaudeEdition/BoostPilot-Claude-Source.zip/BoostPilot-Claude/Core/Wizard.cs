using System.Runtime.InteropServices;
using Microsoft.Win32;
namespace BoostPilotClaude.Core;

public enum Goal { Gaming, CompetitiveGaming, EverydayUse, Streaming, ContentCreation, PowerSaving }

public record HardwareProfile(string Cpu, int Threads, double RamGb, string Gpu, bool IsLaptop, bool OnBattery, double DiskFreeGb, double DiskTotalGb);

public sealed class PlannedChange
{
    public required string Title { get; init; }
    public required string Explain { get; init; }
    public required string Kind { get; init; }   // powerplan | startup | regdword | tempclean
    public string Target { get; init; } = "";
    public string NewValue { get; init; } = "";
    public bool Selected { get; set; }
    public bool Reversible { get; init; } = true;
}

public record WizardPlan(List<PlannedChange> Changes, List<string> Advice);

/// <summary>Reads the real hardware and power state of this PC.</summary>
public static class HardwareScanner
{
    [StructLayout(LayoutKind.Sequential)]
    struct PowerStatus { public byte Ac, Flag, Percent, Saver; public int Life, FullLife; }
    [DllImport("kernel32.dll")] static extern bool GetSystemPowerStatus(out PowerStatus s);

    public static HardwareProfile Scan()
    {
        var cpu = (Registry.GetValue(@"HKEY_LOCAL_MACHINE\HARDWARE\DESCRIPTION\System\CentralProcessor\0", "ProcessorNameString", null) as string)?.Trim() ?? "Unknown CPU";
        var ci = new Microsoft.VisualBasic.Devices.ComputerInfo();
        var gpus = new List<string>();
        using (var k = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}"))
            foreach (var n in k?.GetSubKeyNames() ?? Array.Empty<string>())
            {
                if (n.Length != 4 || !char.IsDigit(n[0])) continue;
                using var sub = k!.OpenSubKey(n);
                if (sub?.GetValue("DriverDesc") is string desc) gpus.Add(desc);
            }
        var gpu = gpus.FirstOrDefault(x => !x.Contains("Intel") && !x.Contains("Basic")) ?? gpus.FirstOrDefault() ?? "Unknown GPU";
        GetSystemPowerStatus(out var p);
        bool laptop = p.Flag != 255 && (p.Flag & 128) == 0;
        var drv = new DriveInfo(Path.GetPathRoot(Environment.SystemDirectory)!);
        return new(cpu, Environment.ProcessorCount, ci.TotalPhysicalMemory / 1073741824.0, gpu, laptop, p.Ac == 0,
                   drv.AvailableFreeSpace / 1073741824.0, drv.TotalSize / 1073741824.0);
    }
}

/// <summary>Turns "what the user wants" plus "what this PC is" into a list of explained, individually approvable changes.</summary>
public static class WizardPlanner
{
    static readonly Dictionary<string, string> Guids = new()
    {
        ["SCHEME_MIN"] = "8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c",
        ["SCHEME_MAX"] = "a1841308-3541-4fab-bc81-f71556f20b4a",
        ["SCHEME_BALANCED"] = "381b4222-f694-41f0-9685-f5bb260df5ae"
    };

    static bool IsActive(string alias)
    {
        try { return string.Equals(PowerPlanManager.Active().Guid, Guids[alias], StringComparison.OrdinalIgnoreCase); } catch { return false; }
    }

    static PlannedChange Reg(string title, string explain, string sub, string name, int value) => new()
    { Title = title, Explain = explain, Kind = "regdword", Target = $"{sub}|{name}", NewValue = value.ToString(), Selected = true };

    public static WizardPlan Build(Goal g, HardwareProfile hw)
    {
        var c = new List<PlannedChange>(); var advice = new List<string>();
        bool gaming = g is Goal.Gaming or Goal.CompetitiveGaming;
        bool perf = gaming || g is Goal.Streaming or Goal.ContentCreation;
        bool onBatt = hw.IsLaptop && hw.OnBattery;

        var (alias, label, why) =
            g == Goal.PowerSaving ? ("SCHEME_MAX", "Power saver", "Lower CPU clocks and shorter idle timers reduce power use and heat. Heavy tasks may feel slower.")
            : perf && !onBatt ? ("SCHEME_MIN", "High performance", "Keeps the CPU at higher clocks so games and heavy apps don't wait for it to speed up. Uses more power and can run warmer.")
            : ("SCHEME_BALANCED", "Balanced", "The Windows default: performance scales with demand.");
        if (onBatt && perf) advice.Add("You're on battery, so the High performance plan was skipped. Plug in and re-run the wizard for the full performance plan.");
        if (!IsActive(alias))
            c.Add(new() { Title = $"Switch power plan to {label}", Explain = why, Kind = "powerplan", Target = alias, Selected = true });

        if (gaming)
        {
            c.Add(Reg("Turn on Windows Game Mode", "Tells Windows to favour the running game over background work. A built-in Windows setting.",
                @"Software\Microsoft\GameBar", "AutoGameModeEnabled", 1));
            c.Add(Reg("Turn off background game recording", "Stops Windows recording gameplay in the background, freeing a little CPU, GPU and disk. You lose 'record the last 30 seconds'.",
                @"Software\Microsoft\Windows\CurrentVersion\GameDVR", "AppCaptureEnabled", 0));
        }
        if (g is Goal.PowerSaving or Goal.CompetitiveGaming)
            c.Add(Reg("Turn off window transparency", "Disables Windows' blur and transparency effects. Cosmetic only, with slightly less GPU work.",
                @"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize", "EnableTransparency", 0));

        foreach (var s in StartupManager.List().Where(i => i.Enabled))
        {
            bool updater = s.Name.Contains("update", StringComparison.OrdinalIgnoreCase) || s.Command.Contains("update", StringComparison.OrdinalIgnoreCase);
            c.Add(new()
            {
                Title = $"Stop '{s.Name}' starting with Windows",
                Explain = updater ? "An auto-updater helper. It isn't uninstalled, and the program still updates when you open it."
                                  : "Optional. It isn't uninstalled and you can re-enable it any time; it just won't run in the background after sign-in.",
                Kind = "startup", Target = s.Name, NewValue = "0", Selected = updater
            });
        }

        var (files, bytes) = TempCleaner.Scan();
        if (bytes >= 100L * 1048576)
            c.Add(new() { Title = $"Delete {bytes / 1048576} MB of old temp files", Kind = "tempclean", Selected = true, Reversible = false,
                Explain = $"{files} files older than 24 hours in your temp folder. Files in use are skipped and apps recreate what they need. This can't be undone." });

        if (hw.RamGb < 8) advice.Add($"This PC has {hw.RamGb:F0} GB of RAM. More RAM would help more than any setting; close heavy apps while you work.");
        if (hw.DiskTotalGb > 0 && hw.DiskFreeGb / hw.DiskTotalGb < 0.1) advice.Add("The system drive is over 90% full, which slows Windows. Free some space in Windows Storage settings.");
        advice.Add("BoostPilot can't check for driver updates or change BIOS settings. Use Windows Update or your GPU maker's app for drivers.");
        return new(c, advice);
    }
}

/// <summary>Applies one planned change: capture the original value, apply, then record it for the Restore Centre.</summary>
public static class ChangeApplier
{
    // Only these per-user (HKCU) values can ever be written. Anything else is refused.
    static readonly HashSet<string> Allowed = new()
    {
        @"Software\Microsoft\GameBar|AutoGameModeEnabled",
        @"Software\Microsoft\Windows\CurrentVersion\GameDVR|AppCaptureEnabled",
        @"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize|EnableTransparency"
    };

    static (string, string) Split(string t) { var i = t.IndexOf('|'); return (t[..i], t[(i + 1)..]); }

    public static string Apply(PlannedChange c, RestoreService r)
    {
        switch (c.Kind)
        {
            case "powerplan": return ApplyPower(c, r);
            case "startup": return ApplyStartup(c, r);
            case "regdword": return ApplyReg(c, r);
            case "tempclean": { var (n, b) = TempCleaner.Clean(); return $"Deleted {n} temp files ({b / 1048576.0:F1} MB)"; }
            default: throw new InvalidOperationException($"Unknown change type '{c.Kind}'.");
        }
    }

    static string ApplyPower(PlannedChange c, RestoreService r)
    {
        var old = PowerPlanManager.Active();
        PowerPlanManager.SetActive(c.Target);
        var now = PowerPlanManager.Active().Name;
        r.Record("powerplan", "Windows power plan", old.Guid, $"Wizard: power plan {old.Name} → {now}");
        return $"Power plan: {old.Name} → {now}";
    }

    static string ApplyStartup(PlannedChange c, RestoreService r)
    {
        bool was = StartupManager.List().FirstOrDefault(i => i.Name == c.Target)?.Enabled ?? true;
        bool want = c.NewValue == "1";
        StartupManager.SetEnabled(c.Target, want);
        r.Record("startup", c.Target, was ? "1" : "0", $"Wizard: startup '{c.Target}' {(want ? "enabled" : "disabled")}");
        return $"Startup '{c.Target}' {(want ? "enabled" : "disabled")}";
    }

    static string ApplyReg(PlannedChange c, RestoreService r)
    {
        if (!Allowed.Contains(c.Target)) throw new InvalidOperationException("That setting isn't on BoostPilot's safe list.");
        var (sub, name) = Split(c.Target);
        using var k = Registry.CurrentUser.CreateSubKey(sub);
        var old = k.GetValue(name) is int i ? i.ToString() : "<missing>";
        k.SetValue(name, int.Parse(c.NewValue), RegistryValueKind.DWord);
        r.Record("regdword", c.Target, old, $"Wizard: {c.Title}");
        return c.Title;
    }

    public static void Undo(RestoreEntry e)
    {
        if (e.Kind != "regdword" || !Allowed.Contains(e.Target)) return;
        var (sub, name) = Split(e.Target);
        using var k = Registry.CurrentUser.CreateSubKey(sub);
        if (e.OldValue == "<missing>") k.DeleteValue(name, false);
        else k.SetValue(name, int.Parse(e.OldValue), RegistryValueKind.DWord);
    }
}
