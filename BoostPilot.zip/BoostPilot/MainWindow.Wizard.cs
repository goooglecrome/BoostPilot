using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using BoostPilot.Core;
namespace BoostPilot;

public partial class MainWindow
{
    int _step; Goal _goal = Goal.EverydayUse; HardwareProfile? _hw; WizardPlan? _plan;

    static readonly (Goal, string, string)[] GoalInfo =
    {
        (Goal.Gaming, "Gaming", "highest sustained performance while keeping Windows stable."),
        (Goal.CompetitiveGaming, "Competitive gaming", "gaming settings plus less background overhead and fewer visual effects."),
        (Goal.EverydayUse, "Everyday use", "balanced performance, power use and responsiveness."),
        (Goal.Streaming, "Streaming", "keeps the CPU responsive for game capture and encoding."),
        (Goal.ContentCreation, "Content creation", "sustained performance for editing and rendering."),
        (Goal.PowerSaving, "Power saving", "lower power use and heat, best for laptops on battery.")
    };
    static readonly string[] StepTitles = { "What do you want from this PC?", "Your PC", "Recommended plan", "Done" };

    static TextBlock T(string s, bool dim = false, double top = 6)
    {
        var tb = new TextBlock { Text = s, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, top, 0, 0) };
        if (dim) tb.Foreground = new SolidColorBrush(Color.FromRgb(0x8A, 0x90, 0x99));
        return tb;
    }

    void ShowStep(int step)
    {
        _step = step; WizBody.Children.Clear(); WizTitle.Text = StepTitles[step];
        WizBack.Visibility = step is 1 or 2 ? Visibility.Visible : Visibility.Collapsed;
        WizNext.Content = step switch { 0 => "Scan my PC", 1 => "Build my plan", 2 => "Apply selected changes", _ => "Open Restore Centre" };
        WizNext.IsEnabled = true;
        switch (step)
        {
            case 0:
                WizBody.Children.Add(T("Pick the closest match. BoostPilot checks your hardware, then recommends settings for it. Nothing changes until you approve it.", true));
                foreach (var (g, name, desc) in GoalInfo)
                {
                    var rb = new RadioButton { Content = $"{name}: {desc}", GroupName = "goal", IsChecked = g == _goal, Tag = g, Margin = new Thickness(0, 10, 0, 0), Foreground = Brushes.White };
                    rb.Checked += (s, _) => _goal = (Goal)((RadioButton)s!).Tag;
                    WizBody.Children.Add(rb);
                }
                break;
            case 1:
                _hw = HardwareScanner.Scan();
                WizBody.Children.Add(T($"CPU: {_hw.Cpu} ({_hw.Threads} threads)"));
                WizBody.Children.Add(T($"Memory: {_hw.RamGb:F0} GB"));
                WizBody.Children.Add(T($"Graphics: {_hw.Gpu}"));
                WizBody.Children.Add(T(_hw.IsLaptop ? $"Device: laptop ({(_hw.OnBattery ? "on battery" : "plugged in")})" : "Device: desktop"));
                WizBody.Children.Add(T($"System drive: {_hw.DiskFreeGb:F0} GB free of {_hw.DiskTotalGb:F0} GB"));
                WizBody.Children.Add(T($"Goal: {GoalInfo.First(x => x.Item1 == _goal).Item2}. Next, BoostPilot builds a plan for it.", true, 14));
                break;
            case 2:
                foreach (var a in _plan!.Advice) WizBody.Children.Add(T("Note: " + a, true));
                WizBody.Children.Add(T("Tick what you want applied. Every reversible change is recorded first, so you can undo it in the Restore Centre.", false, 14));
                foreach (var c in _plan.Changes)
                {
                    var cb = new CheckBox { Content = c.Title, IsChecked = c.Selected, Margin = new Thickness(0, 12, 0, 0), Foreground = Brushes.White, FontWeight = FontWeights.SemiBold };
                    cb.Click += (_, _) => c.Selected = cb.IsChecked == true;
                    var note = T(c.Reversible ? c.Explain : c.Explain + " (Cannot be undone.)", true, 2);
                    note.Margin = new Thickness(22, 2, 0, 0);
                    WizBody.Children.Add(cb); WizBody.Children.Add(note);
                }
                if (_plan.Changes.Count == 0) WizBody.Children.Add(T("This PC already matches the recommended settings for this goal."));
                break;
        }
    }

    void Wiz_Back(object s, RoutedEventArgs e) => ShowStep(_step - 1);

    async void Wiz_Next(object s, RoutedEventArgs e)
    {
        WizNext.IsEnabled = false;
        try
        {
            switch (_step)
            {
                case 0: ShowStep(1); break;
                case 1: _plan = await Task.Run(() => WizardPlanner.Build(_goal, _hw!)); ShowStep(2); break;
                case 2: await ApplyPlan(); break;
                default:
                    WizPanel.Visibility = Visibility.Collapsed; DashPanel.Visibility = Visibility.Collapsed; OptPanel.Visibility = Visibility.Collapsed;
                    RestPanel.Visibility = Visibility.Visible; RefreshRestore(); break;
            }
        }
        catch (Exception ex) { MessageBox.Show(ex.Message, "Setup wizard"); WizNext.IsEnabled = true; }
    }

    async Task ApplyPlan()
    {
        var chosen = _plan!.Changes.Where(c => c.Selected).ToList();
        if (chosen.Count == 0) { MessageBox.Show("Nothing is ticked, so nothing was changed."); WizNext.IsEnabled = true; return; }
        if (MessageBox.Show($"Apply {chosen.Count} change(s)? Each reversible change is recorded first so you can undo it.", "Apply plan", MessageBoxButton.YesNo) != MessageBoxResult.Yes)
        { WizNext.IsEnabled = true; return; }
        var results = await Task.Run(() => chosen.Select(c =>
        {
            try { return "Done: " + ChangeApplier.Apply(c, _r); }
            catch (Exception ex) { return $"Failed: {c.Title}: {ex.Message}"; }
        }).ToList());
        ShowStep(3);
        foreach (var line in results) WizBody.Children.Add(T(line));
        WizBody.Children.Add(T("Anything reversible can be undone from the Restore Centre.", true, 14));
        RefreshStartup(); RefreshRestore();
        try { ModeText.Text = $"Active power plan: {PowerPlanManager.Active().Name}"; } catch { }
    }
}
